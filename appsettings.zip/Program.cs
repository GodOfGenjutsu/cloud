using Microsoft.AspNetCore.Http.Features;
using Sanskar_Admin.BAL;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews(options =>
{
    options.Filters.Add(new CustomAuthorizeAttribute()); // Add the custom authorize attribute globally
});
// Add services to the container.
builder.Services.AddControllersWithViews();
/* Season Setting Starts*/
builder.Services.AddSession();
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
/* Season Setting Ends*/

// Dependency Injections
builder.Services.AddScoped<LoginBAL>();
builder.Services.AddScoped<InquiryBAL>();
builder.Services.AddScoped<StudentBal>();
builder.Services.AddScoped<DashBoardBAL>();
builder.Services.AddScoped<AdminProfileBAL>();
builder.Services.AddScoped<AttendanceBAL>();
builder.Services.AddSingleton<IWebHostEnvironment>(builder.Environment);
builder.Services.Configure<FormOptions>(options =>
{
    options.MultipartBodyLengthLimit = 209715200; // Set the maximum size to 200MB
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    // app.UseExceptionHandler("/Home/Error");
    app.UseExceptionHandler(
        "/Wildcard/ServerError"); // Redirect all server errors to the ServerError action in the Wildcard controller
    app.UseStatusCodePagesWithReExecute(
        "/Wildcard/Error{0}"); // Redirect 404 errors to the Error404 action in the Wildcard controller
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();

//  For Session
app.UseSession();

app.UseAuthorization();

// Auth Route
app.UseEndpoints(endpoints =>
{
    endpoints.MapControllerRoute(
        name: "areas",
        pattern: "{area:exists}/{controller=Auth}/{action=Index}/{id?}"
    );
});

// Student Route
app.UseEndpoints(endpoints =>
{
    endpoints.MapControllerRoute(
        name: "areas",
        pattern: "{area:exists}/{controller=Students}/{action=Index}/{id?}"
    );
});
// Attendance Route
app.UseEndpoints(endpoints =>
{
    endpoints.MapControllerRoute(
        name: "areas",
        pattern: "{area:exists}/{controller=Home}/{action=Index}/{id?}"
    );
});
// Inquiry Route
app.UseEndpoints(endpoints =>
{
    endpoints.MapControllerRoute(
        name: "areas",
        pattern: "{area:exists}/{controller=Inquiry}/{action=Index}/{id?}"
    );
});

// Medium
app.UseEndpoints(endpoints =>
{
    endpoints.MapControllerRoute(
        name: "areas",
        pattern: "{area:exists}/{controller=Medium}/{action=Index}/{id?}"
    );
});

// Board
app.UseEndpoints(endpoints =>
{
    endpoints.MapControllerRoute(
        name: "areas",
        pattern: "{area:exists}/{controller=Board}/{action=Index}/{id?}"
    );
});

// Standard
app.UseEndpoints(endpoints =>
{
    endpoints.MapControllerRoute(
        name: "areas",
        pattern: "{area:exists}/{controller=Standard}/{action=Index}/{id?}"
    );
});

// YearWise Fee Table
app.UseEndpoints(endpoints =>
{
    endpoints.MapControllerRoute(
        name: "areas",
        pattern: "{area:exists}/{controller=YearWiseFee}/{action=Index}/{id?}"
    );
});

// Academic Year Table
app.UseEndpoints(endpoints =>
{
    endpoints.MapControllerRoute(
        name: "areas",
        pattern: "{area:exists}/{controller=AcademicYear}/{action=Index}/{id?}"
    );
});

// Staff Table Route
app.UseEndpoints(endpoints =>
{
    endpoints.MapControllerRoute(
        name: "areas",
        pattern: "{area:exists}/{controller=Staff}/{action=Index}/{id?}"
    );
});

// Subject
app.UseEndpoints(endpoints =>
{
    endpoints.MapControllerRoute(
        name: "areas",
        pattern: "{area:exists}/{controller=Subject}/{action=Index}/{id?}"
    );
});

// Division
app.UseEndpoints(endpoints =>
{
    endpoints.MapControllerRoute(
        name: "areas",
        pattern: "{area:exists}/{controller=Division}/{action=Index}/{id?}"
    );
});

app.UseEndpoints(endpoints =>
{
    endpoints.MapControllerRoute(name: "admin", pattern: "{controller=Admin}/{action=Index}/{id?}");
});

// Dashboard
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Dashboard}/{action=Index}/{id?}");

// Wild Card
app.UseEndpoints(endpoints =>
{
    endpoints.MapControllerRoute(
        name: "wildcard",
        pattern: "{*url}",
        defaults: new { controller = "Wildcard", action = "Error404" }
    );
});
app.Run();