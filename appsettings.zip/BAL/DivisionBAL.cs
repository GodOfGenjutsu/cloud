using Sanskar_Admin.DAL;
using Sanskar_Admin.Models;

namespace Sanskar_Admin.BAL;

public class DivisionBAL
{
    #region Configuration

    private DivisionDAL _divisionDal;

    public DivisionBAL()
    {
        _divisionDal = new DivisionDAL();
    }

    #endregion

    #region Method : PR_Division_Insert

    public bool PR_Division_Insert(Division division)
    {
        try
        {
            return _divisionDal.PR_Division_Insert(division);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Method : PR_Division_Update

    public bool PR_Division_Update(Division division)
    {
        try
        {
            return _divisionDal.PR_Division_Update(division);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Method : PR_Division_Delete

    public bool PR_Division_Delete(int DivisionId)
    {
        try
        {
            return _divisionDal.PR_Division_Delete(DivisionId);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Methos : PR_Division_SelectAll

    public List<Division> PR_Division_SelectAll()
    {
        try
        {
            return _divisionDal.PR_Division_SelectAll();
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Method : PR_Division_SelectByPK

    public Division PR_Division_SelectByPK(int DivisionId)
    {
        try
        {
            return _divisionDal.PR_Division_SelectByPK(DivisionId);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region PR_Standard_DropDown

    public List<Standard> PR_Standard_DropDown()
    {
        try
        {
            return _divisionDal.PR_Standard_DropDown();
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion
}