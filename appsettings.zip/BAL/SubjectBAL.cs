using System.Data;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using Sanskar_Admin.DAL;
using Sanskar_Admin.Models;

namespace Sanskar_Admin.BAL;

public class SubjectBAL
{
    #region Configuration

    private SubjectDAL _subjectDal;

    public SubjectBAL()
    {
        _subjectDal = new SubjectDAL();
    }

    #endregion

    #region Method : PR_Subject_Insert

    public bool PR_Subject_Insert(Subject subject)
    {
        try
        {
            return _subjectDal.PR_Subject_Insert(subject);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Method : PR_Subject_Update

    public bool PR_Subject_Update(Subject subject)
    {
        try
        {
            return _subjectDal.PR_Subject_Update(subject);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Method : PR_Subject_Delete

    public bool PR_Subject_Delete(int SubjectId)
    {
        try
        {
            return
                _subjectDal.PR_Subject_Delete(SubjectId);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Methos : PR_Subject_SelectAll

    public List<Subject> PR_Subject_SelectAll()
    {
        try
        {
            return _subjectDal.PR_Subject_SelectAll();
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Method : PR_Subject_SelectById

    public Subject PR_Subject_SelectById(int SubjectId)
    {
        try
        {
            return _subjectDal.PR_Subject_SelectById(SubjectId);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region GetBoardDropdownList

    public List<BoardDropDownModel> GetBoardDropdownList()
    {
        try
        {
            return _subjectDal.GetBoardDropdownList();
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region GetBoardDropdownList

    public List<StandardDropDownModel> GetStdDropdownList()
    {
        try
        {
            return _subjectDal.GetStdDropdownList();
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region GetMediumDropdownList

    public List<MediumDropDownModel> GetMediumDropdownList()
    {
        try
        {
            return _subjectDal.GetMediumDropdownList();
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion
}