﻿using Sanskar_Admin.DAL;
using Sanskar_Admin.Models;

namespace Sanskar_Admin.BAL;

public class AcademicYearBAL
{
    #region Configuration

    private AcademicYearDAL _academicYearDal;

    public AcademicYearBAL()
    {
        _academicYearDal = new AcademicYearDAL();
    }

    #endregion


    #region Select All

    public List<AcademicYear> PR_AcademicYear_SelectAll()
    {
        try
        {
            return _academicYearDal.PR_AcademicYear_SelectAll();
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            throw;
        }
    }

    #endregion

    #region Select By Id

    public AcademicYear PR_AcademicYear_SelectById(int academicYearId)
    {
        try
        {
            return _academicYearDal.PR_AcademicYear_SelectById(academicYearId);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            throw;
        }
    }

    #endregion

    #region Insert

    public bool PR_AcademicYear_Insert(AcademicYear academicYear)
    {
        try
        {
            return _academicYearDal.PR_AcademicYear_Insert(academicYear);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            throw;
        }
    }

    #endregion

    #region Update

    public bool PR_AcademicYear_Update(AcademicYear academicYear)
    {
        try
        {
            return _academicYearDal.PR_AcademicYear_Update(academicYear);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            throw;
        }
    }

    #endregion

    #region Delete

    public bool PR_AcademicYear_Delete(int academicYearId)
    {
        try
        {
            return _academicYearDal.PR_AcademicYear_Delete(academicYearId);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            throw;
        }
    }

    #endregion
}