﻿using Sanskar_Admin.DAL;
using Sanskar_Admin.Models;

namespace Sanskar_Admin.BAL;

public class StandardBAL
{
    #region Configuration

    private StandardDAL _standardDal;

    public StandardBAL()
    {
        _standardDal = new StandardDAL();
    }

    #endregion

    #region Method : PR_Standard_Insert

    public bool PR_Standard_Insert(Standard standard)
    {
        try
        {
            return _standardDal.PR_Standard_Insert(standard);
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    #endregion

    #region Method : PR_Standard_Delete

    public bool PR_Standard_Delete(int standardId)
    {
        try
        {
            return _standardDal.PR_Standard_Delete(standardId);
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    #endregion

    #region Method : PR_Standard_Update

    public bool PR_Standard_Update(Standard standard)
    {
        try
        {
            return _standardDal.PR_Standard_Update(standard);
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    #endregion

    #region Method : PR_Standard_SelectAll

    public List<Standard> PR_Standard_SelectAll()
    {
        try
        {
            return _standardDal.PR_Standard_SelectAll();
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    #endregion

    #region Method : PR_Standard_SelectByPK

    public Standard PR_Standard_SelectByPK(int StandardId)
    {
        try
        {
            return _standardDal.PR_Standard_SelectByPK(StandardId);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion
}