﻿using Sanskar_Admin.DAL;
using Sanskar_Admin.Models;

namespace Sanskar_Admin.BAL;

public class InquiryBAL
{
    #region Configuration

    private readonly InquiryDAL _inquiryDal;

    public InquiryBAL()
    {
        _inquiryDal = new InquiryDAL();
    }

    #endregion

    #region API_Inquiry_SELECTALL

    public List<Inquiry> PR_Inquiry_SelectAll()
    {
        try
        {
            List<Inquiry> inquiry = _inquiryDal.PR_Inquiry_SelectAll();
            return inquiry;
        }
        catch
        {
            return null;
        }
    }

    #endregion

    #region PR_Inquiry_Delete

    public bool PR_Inquiry_Delete(int InquiryID)
    {
        try
        {
            return _inquiryDal.PR_Inquiry_Delete(InquiryID);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Exception in PR_Inquiry_Delete: {ex.Message}");
            throw;
        }
    }

    #endregion

    #region PR_Inquiry_SelectByPK

    public Inquiry PR_Inquiry_SelectByPK(int InquiryID)
    {
        try
        {
            Inquiry inquiry = _inquiryDal.PR_Inquiry_SelectByPK(InquiryID);
            return inquiry;
        }
        catch (Exception ex)
        {
            return null;
        }
    }

    #endregion

    #region GetBoardsDLL

    public List<Board> GetBoardsDLL()
    {
        try
        {
            return _inquiryDal.GetBoardsDLL();
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region GetMediumsDLL

    public List<Medium> GetMediumsDLL()
    {
        try
        {
            return _inquiryDal.GetMediumsDLL();
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    //
    // #region GetSanskarDLL
    // public List<Sanskar> GetSanskarDLL()
    // {
    //     try
    //     {
    //         return _inquiryDal.GetSanskarDLL();
    //     }
    //     catch (Exception e)
    //     {
    //         Console.WriteLine(e);
    //         throw;
    //     }
    // }
    //
    // #endregion

    #region GetStandardDLL

    public List<Standard> GetStandardDLL()
    {
        try
        {
            return _inquiryDal.GetStandardsDLL();
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region PR_Inquiry_Insert

    public bool PR_Inquiry_Insert(Inquiry inquiryModel)
    {
        try
        {
            return _inquiryDal.PR_Inquiry_Insert(inquiryModel);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion
}