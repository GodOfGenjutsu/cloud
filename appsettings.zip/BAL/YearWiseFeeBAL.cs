﻿using Sanskar_Admin.DAL;
using Sanskar_Admin.Models;

namespace Sanskar_Admin.BAL;

using System;
using System.Collections.Generic;

public class YearWiseFeeBAL
{
    #region Configuration

    private readonly YearWiseFeeDAL _yearWiseFeeDal;

    public YearWiseFeeBAL()
    {
        _yearWiseFeeDal = new YearWiseFeeDAL();
    }

    #endregion

    #region Select All

    public List<YearWiseFee> PR_YearWiseFee_SelectAll()
    {
        try
        {
            return _yearWiseFeeDal.PR_YearWiseFee_SelectAll();
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Select By Id

    public YearWiseFee PR_YearWiseFee_SelectById(int yearWiseFeeId)
    {
        try
        {
            return _yearWiseFeeDal.PR_YearWiseFee_SelectById(yearWiseFeeId);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Insert

    public bool PR_YearWiseFee_Insert(YearWiseFee yearWiseFee)
    {
        try
        {
            // You can add any business logic validations before calling the DAL
            // For example:
            // if (yearWiseFee.TotalFees <= 0)
            // {
            //     throw new Exception("TotalFees should be greater than 0.");
            // }

            return _yearWiseFeeDal.PR_YearWiseFee_Insert(yearWiseFee);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Update

    public bool PR_YearWiseFee_Update(YearWiseFee yearWiseFee)
    {
        try
        {
            // You can add any business logic validations before calling the DAL
            // For example:
            // if (yearWiseFee.TotalFees <= 0)
            // {
            //     throw new Exception("TotalFees should be greater than 0.");
            // }

            return _yearWiseFeeDal.PR_YearWiseFee_Update(yearWiseFee);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Delete

    public bool PR_YearWiseFee_Delete(int yearWiseFeeId)
    {
        try
        {
            // You can add any business logic validations before calling the DAL
            // For example:
            // if (yearWiseFeeId <= 0)
            // {
            //     throw new Exception("Invalid YearWiseFeeId.");
            // }

            return _yearWiseFeeDal.PR_YearWiseFee_Delete(yearWiseFeeId);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion
}