﻿using System.Net;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Caching.Memory;

namespace Sanskar_Admin.BAL;

public class ThrottleLoginAttemptsAttribute : ActionFilterAttribute
{
    private readonly int _requestLimit;
    private readonly TimeSpan _timeSpan;
    private static readonly MemoryCache _cache = new MemoryCache(new MemoryCacheOptions());

    public ThrottleLoginAttemptsAttribute(int requestLimit, int seconds)
    {
        _requestLimit = requestLimit;
        _timeSpan = TimeSpan.FromSeconds(seconds);
    }

    public override void OnActionExecuting(ActionExecutingContext context)
    {
        var request = context.HttpContext.Request;
        var key = $"{request.Path}_{request.HttpContext.Connection.RemoteIpAddress}";

        if (!_cache.TryGetValue(key, out int attempts))
        {
            _cache.Set(key, 1, _timeSpan);
        }
        else
        {
            if (attempts >= _requestLimit)
            {
                context.Result = new ContentResult
                {
                    Content = "Too many login attempts. Please try again later.",
                    ContentType = "text/plain",
                    StatusCode = (int)HttpStatusCode.TooManyRequests
                };
                return;
            }
            _cache.Set(key, attempts + 1, _timeSpan);
        }

        base.OnActionExecuting(context);
    }
}
