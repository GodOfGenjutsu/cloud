﻿using Sanskar_Admin.DAL;
using Sanskar_Admin.Models;

namespace Sanskar_Admin.BAL;

public class BoardBAL
{
    #region Configuration

    private BoardDAL _boardDal;

    public BoardBAL()
    {
        _boardDal = new BoardDAL();
    }

    #endregion

    #region Method : PR_Board_Insert

    public bool PR_Board_Insert(Board board)
    {
        try
        {
            return _boardDal.PR_Board_Insert(board);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Method : PR_Board_Delete

    public bool PR_Board_Delete(int boardId)
    {
        try
        {
            return _boardDal.PR_Board_Delete(boardId);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Method : PR_Board_Update

    public bool PR_Board_Update(Board board)
    {
        try
        {
            return _boardDal.PR_Board_Update(board);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region method : PR_Board_SelectAll

    public List<Board> PR_Board_SelectAll()
    {
        try
        {
            return _boardDal.PR_Board_SelectAll();
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Method : PR_Board_SelectByPK

    public Board PR_Board_SelectByPK(int boardId)
    {
        try
        {
            return _boardDal.PR_Board_SelectByPK(boardId);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion
}