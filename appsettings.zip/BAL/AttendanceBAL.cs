﻿using Sanskar_Admin.DAL;
using Sanskar_Admin.Models;

namespace Sanskar_Admin.BAL;

public class AttendanceBAL
{
    #region Configuration
    private readonly AttendanceDAL _attendanceDAL;

    public AttendanceBAL()
    {
        _attendanceDAL = new AttendanceDAL();
    }
    #endregion

    #region SelectByDate
    public List<Attendance> PR_Attendance_SelectByDate(DateTime date, int standardId, int divisionId)
    {
        try
        {
            return _attendanceDAL.PR_Attendance_SelectByDate(date, standardId, divisionId);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            throw;
        }
    }
    #endregion

    #region SelectByStudentId
    public List<Attendance> PR_Attendance_SelectByStudentId(int studentId, DateTime startDate, DateTime endDate)
    {
        try
        {
            return _attendanceDAL.PR_Attendance_SelectByStudentId(studentId, startDate, endDate);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            throw;
        }
    }
    #endregion

    #region Insert
    public bool PR_Attendance_Insert(List<Attendance> attendances)
    {
        try
        {
            return _attendanceDAL.PR_Attendance_Insert(attendances);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            return false;
        }
    }
    #endregion

    #region Update
    public bool PR_Attendance_Update(List<Attendance> attendances)
    {
        try
        {
            return _attendanceDAL.PR_Attendance_Update(attendances);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            return false;
        }
    }
    #endregion
}