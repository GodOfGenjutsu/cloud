﻿using Sanskar_Admin.DAL;
using Sanskar_Admin.Models;

namespace Sanskar_Admin.BAL;

public class StaffBAL
{
    #region Configuration

    private StaffDAL _staffDal;

    public StaffBAL()
    {
        _staffDal = new StaffDAL();
    }

    #endregion

    #region Method : PR_Staff_SelectAll

    public List<Staff> PR_Staff_SelectAll()
    {
        try
        {
            return _staffDal.PR_Staff_SelectAll();
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Method : PR_Staff_SelectById

    public Staff PR_Staff_SelectById(int StaffId)
    {
        try
        {
            return _staffDal.PR_Staff_SelectById(StaffId);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region PR_Staff_Insert

    public bool PR_Staff_Insert(Staff StaffModel)
    {
        try
        {
            return _staffDal.PR_Staff_Insert(StaffModel);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Method : PR_Staff_Update

    public bool PR_Staff_Update(Staff Staff)
    {
        try
        {
            return _staffDal.PR_Staff_Update(Staff);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            throw;
        }
    }

    #endregion

    #region Method : PR_Staff_Delete

    public bool PR_Staff_Delete(int StaffId)
    {
        try
        {
            return _staffDal.PR_Staff_Delete(StaffId);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion
}