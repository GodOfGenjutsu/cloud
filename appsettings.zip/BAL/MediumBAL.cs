﻿using Sanskar_Admin.DAL;
using Sanskar_Admin.Models;

namespace Sanskar_Admin.BAL;

public class MediumBAL
{
    #region Configuration

    private MediumDAL _mediumDAL;

    public MediumBAL()
    {
        _mediumDAL = new MediumDAL();
    }

    #endregion

    #region Method : PR_Medium_Insert

    public bool PR_Medium_Insert(Medium medium)
    {
        try
        {
            return _mediumDAL.PR_Medium_Insert(medium);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            throw;
        }
    }

    #endregion

    #region Method : PR_Medium_Delete

    public bool PR_Medium_Delete(int MediumId)
    {
        try
        {
            return _mediumDAL.PR_Medium_Delete(MediumId);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            throw;
        }
    }

    #endregion

    #region Method : PR_Medium_Update

    public bool PR_Medium_Update(Medium medium)
    {
        try
        {
            return _mediumDAL.PR_Medium_Update(medium);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            throw;
        }
    }

    #endregion

    #region Method : PR_Medium_SelectAll

    public List<Medium> PR_Medium_SelectAll()
    {
        try
        {
            return _mediumDAL.PR_Medium_SelectAll();
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            throw;
        }
    }

    #endregion

    #region Method : PR_Medium_SelectByPK

    public Medium PR_Medium_SelectByPK(int MediumId)
    {
        try
        {
            return _mediumDAL.PR_Medium_SelectByPK(MediumId);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            throw;
        }
    }

    #endregion
}