﻿using Sanskar_Admin.DAL;
using Sanskar_Admin.Models;

namespace Sanskar_Admin.BAL;

public class AdminProfileBAL
{
    private AdminProfileDAL _adminProfileDal;
    public AdminProfileBAL()
    {
        _adminProfileDal = new AdminProfileDAL();
    }
    #region AdminBy ID

    public AdminProfileViewModel AdminProfile_SelectByID()
    {
        try
        {
            return _adminProfileDal.AdminProfile_SelectByID();
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }
    #endregion
    
    #region Profile Update

    public bool UpdateAdminProfile(AdminProfileViewModel model)
    {
        try
        {
            return _adminProfileDal.UpdateAdminProfile(model);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }
    #endregion
}