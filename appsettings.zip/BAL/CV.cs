﻿namespace Sanskar_Admin.BAL;

public class CV
{
    private static IHttpContextAccessor _httpContextAccessor;

    static CV()
    {
        _httpContextAccessor = new HttpContextAccessor();
    }

    public static int? UserID()
    {
        return Convert.ToInt32(_httpContextAccessor.HttpContext.Session.GetInt32("UserID"));
    }

    public static int SanskarID()
    {
        return Convert.ToInt32(_httpContextAccessor.HttpContext.Session.GetInt32("SanskarID"));
    }

    public static string UserName()
    {
        return _httpContextAccessor.HttpContext.Session.GetString("UserName");
    }

    public static string Email()
    {
        return _httpContextAccessor.HttpContext.Session.GetString("Email");
    }

    public static string Role()
    {
        return _httpContextAccessor.HttpContext.Session.GetString("UserRole");
    }

    public static string ProfileIMG()
    {
        // Check if the profile image path exists in the session
        var profileImagePath = _httpContextAccessor.HttpContext.Session.GetString("ProfileImage");

        // If it exists, return it; otherwise, return the default path
        return string.IsNullOrEmpty(profileImagePath) ? "/assets/img/profile-img.jpg" :"/uploads/profile/"+ profileImagePath;
    }

    
}