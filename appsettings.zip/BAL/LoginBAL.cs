﻿/*using Sanskar_Admin.Areas.Auth.Models;
using Sanskar_Admin.DAL;
using Sanskar_Admin.Models;

namespace Sanskar_Admin.BAL;

public class LoginBAL
{
    #region Configuration

    private static LoginDAL _db;

    public LoginBAL()
    {
        _db = new LoginDAL();
    }

    #endregion

    #region PR_Admin_Login

    public Admin PR_Admin_Login(Login model)
    {
        try
        {
            return _db.PR_Admin_Login(model);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion
}*/

// BAL/LoginBAL.cs

using Sanskar_Admin.Areas.Auth.Models;
using Sanskar_Admin.DAL;
using Sanskar_Admin.Models;

namespace Sanskar_Admin.BAL;

public class LoginBAL
{
    #region Config

    private readonly LoginDAL _loginDal;

    public LoginBAL()
    {
        _loginDal = new LoginDAL();
    }

    #endregion

    #region Method : Admin : Login

    public Admin? PR_Admin_Login(Login model)
    {
        try
        {
            return _loginDal.PR_Admin_Login(model);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Method : Staff : Login

    public Staff? PR_Staff_Login(Login model)
    {
        try
        {
            return _loginDal.PR_Staff_Login(model);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Method : Student : Login

    public Student? PR_Student_Login(Login model)
    {
        try
        {
            return _loginDal.PR_Student_Login(model);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion
}