﻿using Sanskar_Admin.DAL;
using Sanskar_Admin.Models;

namespace Sanskar_Admin.BAL;

public class DashBoardBAL
{
    #region Configuration

    private readonly DashBoardDAL _dashBoardDal;

    public DashBoardBAL()
    {
        _dashBoardDal = new DashBoardDAL();
    }

    #endregion

    #region Method: PR_DashBoard_Conunt

    public DashboardViewModel PR_DashBoard_Conunt()
    {
        try
        {
            return _dashBoardDal.PR_DashBoard_Conunt();
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Select All

    public List<Inquiry> DashBoard_Inquiry_SelectAll()
    {
        try
        {
            return _dashBoardDal.DashBoard_Inquiry_SelectAll();
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion
}