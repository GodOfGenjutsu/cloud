﻿using Sanskar_Admin.DAL;
using Sanskar_Admin.Models;

namespace Sanskar_Admin.BAL;

public class StudentBal
{
    #region Configuration

    private StudentDAL _studentDal;

    public StudentBal()
    {
        _studentDal = new StudentDAL();
    }

    #endregion

    #region Select All

    public List<Student> PR_Student_SelectAll()
    {
        try
        {
            return _studentDal.PR_Student_SelectAll();
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Select By Id

    public Student PR_Student_SelectById(int studentId)
    {
        try
        {
            return _studentDal.PR_Student_SelectById(studentId);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region insert

    public bool PR_Student_Insert(Student student)
    {
        try
        {
            return _studentDal.PR_Student_Insert(student);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Update

    public bool PR_Student_Update(Student student)
    {
        try
        {
            return _studentDal.PR_Student_Update(student);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Delete

    public bool PR_Student_Delete(int studentId)
    {
        try
        {
            return _studentDal.PR_Student_Delete(studentId);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Board DropDown

    public List<BoardDropDownModel> PR_Board_DropDownList()
    {
        try
        {
            return _studentDal.PR_Board_DropDownList();
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Division DropDown

    public List<DivisionDropDownModel> PR_Division_DropDownList()
    {
        try
        {
            return _studentDal.PR_Division_DropDownList();
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Medium DropDown

    public List<MediumDropDownModel> PR_Medium_DropDownList()
    {
        try
        {
            return _studentDal.PR_Medium_DropDownList();
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Standard DropDown

    public List<StandardDropDownModel> PR_Standard_DropDownList()
    {
        try
        {
            return _studentDal.PR_Standard_DropDownList();
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region AcademicYear DropDown

    public List<AcademicYearDropDown> PR_AcademicYear_DropDown()
    {
        try
        {
            return _studentDal.PR_AcademicYear_DropDown();
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion
}