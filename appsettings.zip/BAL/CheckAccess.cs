﻿/*using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Routing;

namespace Sanskar_Admin.BAL;

 public class CheckAccess : ActionFilterAttribute, IAuthorizationFilter
{
    public void OnAuthorization(AuthorizationFilterContext context)
    {
        if (context.HttpContext.Session.GetString("UserID") == null)
        {
            context.Result = new RedirectToRouteResult(
                new RouteValueDictionary
                {
                    { "area", "Auth" },
                    { "controller", "Auth" },
                    { "action", "Login" }
                });
        }
    }

    public override void OnResultExecuting(ResultExecutingContext filterContext)
    {
        filterContext.HttpContext.Response.Headers["Cache-Control"] = "no-cache, no-store, must-revalidate";
        filterContext.HttpContext.Response.Headers["Expires"] = "-1";
        filterContext.HttpContext.Response.Headers["Pragma"] = "no-cache";
        base.OnResultExecuting(filterContext);
    }
} */



// CustomAuthorizeAttribute.cs
// CustomAuthorizeAttribute.cs
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Routing;
using Microsoft.AspNetCore.Authorization;

namespace Sanskar_Admin.BAL;

public class CustomAuthorizeAttribute : TypeFilterAttribute
{
    public CustomAuthorizeAttribute(params string[] roles) : base(typeof(CustomAuthorizeFilter))
    {
        Arguments = new object[] { roles };
    }
}

public class CustomAuthorizeFilter : IAuthorizationFilter
{
    private readonly string[] _roles;

    public CustomAuthorizeFilter(string[] roles)
    {
        _roles = roles;
    }

    public void OnAuthorization(AuthorizationFilterContext context)
    {
        // Allow anonymous access if the action has the [AllowAnonymous] attribute
        if (context.ActionDescriptor.EndpointMetadata.OfType<AllowAnonymousAttribute>().Any())
        {
            return;
        }

        var userId = context.HttpContext.Session.GetInt32("UserID");
        var role = context.HttpContext.Session.GetString("UserRole");

        // Check if the user is not authenticated
        if (!userId.HasValue)
        {
            context.Result = new RedirectToRouteResult(
                new RouteValueDictionary
                {
                    { "area", "Auth" },
                    { "controller", "Auth" },
                    { "action", "Login" }
                });
            return;
        }

        // Check if the user has the required role
        if (_roles != null && _roles.Length > 0 && (string.IsNullOrEmpty(role) || !_roles.Contains(role)))
        {
            context.Result = new RedirectToRouteResult(
                new RouteValueDictionary
                {
                    { "controller", "Wildcard" },
                    { "action", "Error404" }
                });
        }
    }
}