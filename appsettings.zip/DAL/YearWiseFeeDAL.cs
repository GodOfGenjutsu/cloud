﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using Sanskar_Admin.Models;

namespace Sanskar_Admin.DAL;

public class YearWiseFeeDAL : DAL_Helper
{
    #region Configuration

    private readonly SqlDatabase _sqlDatabase;

    public YearWiseFeeDAL()
    {
        _sqlDatabase = new SqlDatabase(ConnStr);
    }

    #endregion

    #region Select All

    public List<YearWiseFee> PR_YearWiseFee_SelectAll()
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_YearWiseFee_SelectAll");

            List<YearWiseFee> yearWiseFees = new List<YearWiseFee>();

            using (IDataReader idr = _sqlDatabase.ExecuteReader(cmd))
            {
                while (idr.Read())
                {
                    YearWiseFee obj = new YearWiseFee
                    {
                        YearWiseFeeId = Convert.ToInt32(idr["YearWiseFeeId"]),
                        BoardId = Convert.ToInt32(idr["BoardId"]),
                        BoardName = Convert.ToString(
                            idr["BoardName"]), // Assuming the column name is BoardName in the result set
                        StandardId = Convert.ToInt32(idr["StandardId"]),
                        StandardName =
                            Convert.ToString(
                                idr["StandardName"]), // Assuming the column name is StandardName in the result set
                        MediumId = Convert.ToInt32(idr["MediumId"]),
                        MediumName =
                            Convert.ToString(
                                idr["MediumName"]), // Assuming the column name is MediumName in the result set
                        AcademicYearId = Convert.ToInt32(idr["AcademicYearId"]),
                        TotalFees = Convert.ToDecimal(idr["TotalFees"]),
                        CreatedAt = Convert.ToDateTime(idr["CreatedAt"]),
                        ModifiedAt = idr["ModifiedAt"] != DBNull.Value
                            ? Convert.ToDateTime(idr["ModifiedAt"])
                            : (DateTime?)null,
                        AcademicYear = Convert.ToString(idr["AcademicYear"]),
                        StartingMonth = Convert.ToDateTime(idr["StartingMonth"]),
                        EndingMonth = Convert.ToDateTime(idr["EndingMonth"]),
                        StartingYear = Convert.ToInt32(idr["StartingYear"]),
                        EndingYear = Convert.ToInt32(idr["EndingYear"])
                    };

                    yearWiseFees.Add(obj);
                }
            }

            return yearWiseFees;
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Select By Id

    public YearWiseFee PR_YearWiseFee_SelectById(int yearWiseFeeId)
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_YearWiseFee_SelectById");
            _sqlDatabase.AddInParameter(cmd, "YearWiseFeeId", SqlDbType.Int, yearWiseFeeId);

            YearWiseFee yearWiseFee = null;

            using (IDataReader idr = _sqlDatabase.ExecuteReader(cmd))
            {
                if (idr.Read())
                {
                    yearWiseFee = new YearWiseFee
                    {
                        YearWiseFeeId = Convert.ToInt32(idr["YearWiseFeeId"]),
                        BoardId = Convert.ToInt32(idr["BoardId"]),
                        StandardId = Convert.ToInt32(idr["StandardId"]),
                        MediumId = Convert.ToInt32(idr["MediumId"]),
                        AcademicYearId = Convert.ToInt32(idr["AcademicYearId"]),
                        TotalFees = Convert.ToDecimal(idr["TotalFees"]),
                        CreatedAt = Convert.ToDateTime(idr["CreatedAt"]),
                        ModifiedAt = idr["ModifiedAt"] != DBNull.Value
                            ? Convert.ToDateTime(idr["ModifiedAt"])
                            : (DateTime?)null
                    };
                }
            }

            return yearWiseFee;
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Insert

    public bool PR_YearWiseFee_Insert(YearWiseFee yearWiseFee)
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_YearWiseFee_Insert");

            _sqlDatabase.AddInParameter(cmd, "BoardId", SqlDbType.Int, yearWiseFee.BoardId);
            _sqlDatabase.AddInParameter(cmd, "StandardId", SqlDbType.Int, yearWiseFee.StandardId);
            _sqlDatabase.AddInParameter(cmd, "MediumId", SqlDbType.Int, yearWiseFee.MediumId);
            _sqlDatabase.AddInParameter(cmd, "AcademicYearId", SqlDbType.Int, yearWiseFee.AcademicYearId);
            _sqlDatabase.AddInParameter(cmd, "TotalFees", SqlDbType.Decimal, yearWiseFee.TotalFees);
            // _sqlDatabase.AddInParameter(cmd, "ClassesId", SqlDbType.Int, 1);

            return Convert.ToBoolean(_sqlDatabase.ExecuteNonQuery(cmd));
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Update

    public bool PR_YearWiseFee_Update(YearWiseFee yearWiseFee)
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_YearWiseFee_Update");

            _sqlDatabase.AddInParameter(cmd, "YearWiseFeeId", SqlDbType.Int, yearWiseFee.YearWiseFeeId);
            _sqlDatabase.AddInParameter(cmd, "BoardId", SqlDbType.Int, yearWiseFee.BoardId);
            _sqlDatabase.AddInParameter(cmd, "StandardId", SqlDbType.Int, yearWiseFee.StandardId);
            _sqlDatabase.AddInParameter(cmd, "MediumId", SqlDbType.Int, yearWiseFee.MediumId);
            _sqlDatabase.AddInParameter(cmd, "AcademicYearId", SqlDbType.Int, yearWiseFee.AcademicYearId);
            _sqlDatabase.AddInParameter(cmd, "TotalFees", SqlDbType.Decimal, yearWiseFee.TotalFees);

            return Convert.ToBoolean(_sqlDatabase.ExecuteNonQuery(cmd));
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Delete

    public bool PR_YearWiseFee_Delete(int yearWiseFeeId)
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_YearWiseFee_Delete");

            _sqlDatabase.AddInParameter(cmd, "YearWiseFeeId", SqlDbType.Int, yearWiseFeeId);

            return Convert.ToBoolean(_sqlDatabase.ExecuteNonQuery(cmd));
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion
}