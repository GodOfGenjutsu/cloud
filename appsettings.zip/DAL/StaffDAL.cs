﻿using System.Data;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using Sanskar_Admin.Models;

namespace Sanskar_Admin.DAL;

public class StaffDAL : DAL_Helper
{
    #region Configurations

    private static SqlDatabase _sqlDatabase;

    public StaffDAL()
    {
        _sqlDatabase = new SqlDatabase(ConnStr);
    }

    #endregion

    #region Method : PR_Staff_SelectAll

    public List<Staff> PR_Staff_SelectAll()
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Staff_SelectAll");
            // _sqlDatabase.AddInParameter(cmd, "ClassesId", SqlDbType.Int, 1);
            List<Staff> _staff = new List<Staff>();
            using (IDataReader idr = _sqlDatabase.ExecuteReader(cmd))
            {
                while (idr.Read())
                {
                    Staff _sf = new Staff();
                    _sf.StaffID = Convert.ToInt32(idr["StaffId"]);
                    _sf.StaffID = Convert.ToInt32(idr["StaffID"]);
                    // _sf.ClassesId = Convert.ToInt32(idr["ClassesId"]);
                    _sf.StaffName = idr["StaffName"].ToString();
                    _sf.StaffCode = idr["StaffCode"].ToString();
                    _sf.Birthdate = idr["Birthdate"] != DBNull.Value ? ((DateTime)idr["Birthdate"]) : DateTime.MinValue;
                    _sf.ContectNo = idr["ContactNo"].ToString();
                    _sf.Email = idr["Email"].ToString();
                    _sf.Password = idr["Password"].ToString();
                    _sf.Gender = idr["Gender"].ToString();
                    _sf.JoiningDate = idr["JoiningDate"] != DBNull.Value
                        ? ((DateTime)idr["JoiningDate"])
                        : DateTime.MinValue;

                    _sf.Salary = Convert.ToInt32(idr["Salary"]);
                    _sf.Remark = idr["Remark"].ToString();

                    _staff.Add(_sf);
                }
            }

            return _staff;
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Method : PR_Staff_SelectById

    public Staff PR_Staff_SelectById(int staffId)
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Staff_SelectById");
            _sqlDatabase.AddInParameter(cmd, "StaffId", SqlDbType.Int, staffId);
            // _sqlDatabase.AddInParameter(cmd, "ClassesId", SqlDbType.Int, 1);

            Staff _sf = null;
            using (IDataReader idr = _sqlDatabase.ExecuteReader(cmd))
            {
                if (idr.Read())
                {
                    _sf = new Staff();
                    _sf.StaffID = Convert.ToInt32(idr["StaffID"]);
                    // _sf.ClassesId = Convert.ToInt32(idr["ClassesId"]);
                    _sf.StaffName = idr["StaffName"].ToString();
                    _sf.StaffCode = idr["StaffCode"].ToString();
                    _sf.Birthdate = idr["Birthdate"] != DBNull.Value ? ((DateTime)idr["Birthdate"]) : DateTime.MinValue;
                    _sf.ContectNo = idr["ContactNo"].ToString();
                    _sf.Email = idr["Email"].ToString();
                    _sf.Password = idr["Password"].ToString();
                    _sf.Gender = idr["Gender"].ToString();
                    _sf.JoiningDate = idr["JoiningDate"] != DBNull.Value
                        ? ((DateTime)idr["JoiningDate"])
                        : DateTime.MinValue;

                    _sf.Salary = Convert.ToInt32(idr["Salary"]);
                    _sf.Remark = idr["Remark"].ToString();
                }
            }

            return _sf;
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Method : PR_Staff_Insert

    public bool PR_Staff_Insert(Staff staffModel)
    {
        try
        {
            DbCommand dbCommand = _sqlDatabase.GetStoredProcCommand("PR_Staff_Insert");
            // _sqlDatabase.AddInParameter(dbCommand, "ClassesId", SqlDbType.Int, 1);
            _sqlDatabase.AddInParameter(dbCommand, "@StaffName", SqlDbType.VarChar, staffModel.StaffName);
            _sqlDatabase.AddInParameter(dbCommand, "@StaffCode", SqlDbType.VarChar, staffModel.StaffCode);
            _sqlDatabase.AddInParameter(dbCommand, "@Birthdate", SqlDbType.DateTime, staffModel.Birthdate);
            _sqlDatabase.AddInParameter(dbCommand, "@ContectNo", SqlDbType.VarChar, staffModel.ContectNo);
            _sqlDatabase.AddInParameter(dbCommand, "@Email", SqlDbType.VarChar, staffModel.Email);
            _sqlDatabase.AddInParameter(dbCommand, "@JoiningDate", SqlDbType.DateTime, staffModel.JoiningDate);
            _sqlDatabase.AddInParameter(dbCommand, "@Salary", SqlDbType.Int, staffModel.Salary);
            _sqlDatabase.AddInParameter(dbCommand, "@Remark", SqlDbType.VarChar, staffModel.Remark);

            // Hash the password
            string hashedPassword = BCrypt.Net.BCrypt.HashPassword(staffModel.Password);
            _sqlDatabase.AddInParameter(dbCommand, "@Password", SqlDbType.VarChar, hashedPassword); // Store hashed password

            _sqlDatabase.AddInParameter(dbCommand, "@Gender", SqlDbType.VarChar, staffModel.Gender);
            return Convert.ToBoolean(_sqlDatabase.ExecuteNonQuery(dbCommand));
        }
        catch (Exception ex)
        {
            return false;
        }
    }

    #endregion

    #region Method : PR_Staff_Update

    public bool PR_Staff_Update(Staff staff)
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Staff_Update");
            _sqlDatabase.AddInParameter(cmd, "StaffID", SqlDbType.Int, staff.StaffID);
            // _sqlDatabase.AddInParameter(cmd, "ClassesId", SqlDbType.Int, 1);
            _sqlDatabase.AddInParameter(cmd, "StaffName", SqlDbType.NVarChar, staff.StaffName);
            _sqlDatabase.AddInParameter(cmd, "StaffCode", SqlDbType.NVarChar, staff.StaffCode);
            _sqlDatabase.AddInParameter(cmd, "Birthdate", SqlDbType.Date, staff.Birthdate);
            _sqlDatabase.AddInParameter(cmd, "ContectNo", SqlDbType.NVarChar, staff.ContectNo);
            _sqlDatabase.AddInParameter(cmd, "Email", SqlDbType.NVarChar, staff.Email);
            _sqlDatabase.AddInParameter(cmd, "JoiningDate", SqlDbType.Date, staff.JoiningDate);
            _sqlDatabase.AddInParameter(cmd, "Salary", SqlDbType.Int, staff.Salary);
            _sqlDatabase.AddInParameter(cmd, "Remark", SqlDbType.NVarChar, staff.Remark);

            // Hash the password if it's being updated
            string hashedPassword = BCrypt.Net.BCrypt.HashPassword(staff.Password);
            _sqlDatabase.AddInParameter(cmd, "Password", SqlDbType.VarChar, hashedPassword); // Store hashed password

            _sqlDatabase.AddInParameter(cmd, "Gender", SqlDbType.VarChar, staff.Gender);

            return Convert.ToBoolean((_sqlDatabase.ExecuteNonQuery(cmd)));
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Method : PR_Staff_Delete

    public bool PR_Staff_Delete(int StaffId)
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Staff_Delete");
            _sqlDatabase.AddInParameter(cmd, "@StaffId", SqlDbType.Int, StaffId);
            // _sqlDatabase.AddInParameter(cmd, "@ClassesId", SqlDbType.Int, 1);
            return Convert.ToBoolean(_sqlDatabase.ExecuteNonQuery(cmd));
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            throw;
        }
    }

    #endregion

    #region GetSanskarDLL

    public List<Sanskar> GetSanskarDLL()
    {
        List<Sanskar> SanskarList = new List<Sanskar>();

        try
        {
            // Execute SQL command to fetch Sanskar from the database
            using (DbCommand dbCommand = _sqlDatabase.GetStoredProcCommand("GetSanskarDropdownList"))
            {
                using (IDataReader dataReader = _sqlDatabase.ExecuteReader(dbCommand))
                {
                    while (dataReader.Read())
                    {
                        Sanskar Sanskar = new Sanskar();
                        // Sanskar.ClassesId = Convert.ToInt32(dataReader["ClassesId"]);
                        Sanskar.SanskarName = dataReader["SanskarName"].ToString();
                        // Add more properties as needed

                        SanskarList.Add(Sanskar);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            // Log or handle the exception
            // For simplicity, let's rethrow the exception
            throw;
        }

        return SanskarList;
    }

    #endregion
}