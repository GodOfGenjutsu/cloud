﻿using Sanskar_Admin.Models;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System.Data.Common;
using System.Data;
using Sanskar_Admin.BAL;

namespace Sanskar_Admin.DAL;

public class MediumDAL : DAL_Helper
{
    #region Configurations

    private static SqlDatabase _sqlDatabase;

    public MediumDAL()
    {
        _sqlDatabase = new SqlDatabase(ConnStr);
    }

    #endregion

    #region Method : PR_Medium_Insert

    public bool PR_Medium_Insert(Medium medium)
    {
        try
        {
            DbCommand dbCommand = _sqlDatabase.GetStoredProcCommand("PR_Medium_Insert");

            //Add Parameter Into SP
            _sqlDatabase.AddInParameter(dbCommand, "@MediumName", SqlDbType.VarChar, medium.MediumName);
            // _sqlDatabase.AddInParameter(dbCommand, "@SanskarID", SqlDbType.Int, CV.SanskarID());
            return Convert.ToBoolean(_sqlDatabase.ExecuteNonQuery(dbCommand));
        }
        catch (Exception ex)
        {
            return false;
        }
    }

    #endregion

    #region Method : PR_Medium_Delete

    public bool PR_Medium_Delete(int MediumId)
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Medium_Delete");
            // Set parameters for the sp
            _sqlDatabase.AddInParameter(cmd, "MediumId", SqlDbType.Int, MediumId);
            // _sqlDatabase.AddInParameter(cmd, "SanskarID", SqlDbType.Int, CV.SanskarID());

            // Execute the SP
            return Convert.ToBoolean(_sqlDatabase.ExecuteNonQuery(cmd));
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    #endregion

    #region Method : PR_Medium_Update

    public bool PR_Medium_Update(Medium medium)
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Medium_Update");
            _sqlDatabase.AddInParameter(cmd, "@MediumId", SqlDbType.Int, medium.MediumId);
            // _sqlDatabase.AddInParameter(cmd, "@SanskarID", SqlDbType.Int, CV.SanskarID());
            _sqlDatabase.AddInParameter(cmd, "@MediumName", SqlDbType.VarChar, medium.MediumName);

            //Execute the Query
            return Convert.ToBoolean(_sqlDatabase.ExecuteNonQuery(cmd));
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    #endregion

    #region Method : PR_Medium_SelectAll

    public List<Medium> PR_Medium_SelectAll()
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Medium_SelectAll");
            // _sqlDatabase.AddInParameter(cmd, "SanskarID", SqlDbType.Int, CV.SanskarID());
            List<Medium> _medium = new List<Medium>();
            using (IDataReader idr = _sqlDatabase.ExecuteReader(cmd))
            {
                while (idr.Read())
                {
                    Medium _md = new Medium();
                    _md.MediumId = Convert.ToInt32(idr["MediumId"]);
                    // _md.SanskarID = Convert.ToInt32(idr["SanskarID"]);
                    _md.MediumName = idr["MediumName"].ToString();

                    // 
                    _md.CreatedAt = idr["CreatedAt"] != DBNull.Value
                        ? Convert.ToDateTime(idr["CreatedAt"])
                        : (DateTime?)null;
                    _md.ModifiedAt = idr["ModifiedAt"] != DBNull.Value
                        ? Convert.ToDateTime(idr["ModifiedAt"])
                        : (DateTime?)null;

                    _medium.Add(_md);
                }
            }

            return _medium; // Make sure to return the list
        }
        catch (Exception ex)
        {
            // Log the exception
            return null;
        }
    }

    #endregion

    #region Method : PR_Medium_SelectByPK

    public Medium PR_Medium_SelectByPK(int MediumId)
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Medium_SelectByPK");
            _sqlDatabase.AddInParameter(cmd, "MediumId", SqlDbType.Int, MediumId);
            // _sqlDatabase.AddInParameter(cmd, "SanskarID", SqlDbType.Int, CV.SanskarID());
            Medium medium = null;
            using (IDataReader idr = _sqlDatabase.ExecuteReader(cmd))
            {
                if (idr.Read())
                {
                    medium = new Medium
                    {
                        MediumId = Convert.ToInt32(idr["MediumId"]),
                        // SanskarID = Convert.ToInt32(idr["SanskarID"]),
                       
                        MediumName = idr["MediumName"].ToString(),
                        CreatedAt = idr["CreatedAt"] != DBNull.Value
                            ? Convert.ToDateTime(idr["CreatedAt"])
                            : (DateTime?)null,
                        ModifiedAt = idr["ModifiedAt"] != DBNull.Value
                            ? Convert.ToDateTime(idr["ModifiedAt"])
                            : (DateTime?)null
                    };
                }
            }

            return medium;
        }
        catch (Exception ex)
        {
            return null;
        }
    }

    #endregion
}