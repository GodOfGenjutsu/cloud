using System.Data;
using System.Data.Common;
using System.Data.SqlTypes;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using Sanskar_Admin.BAL;
using Sanskar_Admin.Models;

namespace Sanskar_Admin.DAL;

public class DivisionDAL : DAL_Helper
{
    #region Configuration

    private static SqlDatabase _sqlDatabase;

    public DivisionDAL()
    {
        _sqlDatabase = new SqlDatabase(ConnStr);
    }

    #endregion

    #region Method : PR_Division_Insert

    public bool PR_Division_Insert(Division division)
    {
        try
        {
            DbCommand dbCommand = _sqlDatabase.GetStoredProcCommand("PR_Division_Insert");

            //Add Paramter Into SP
            // _sqlDatabase.AddInParameter(dbCommand, "@SanskarID", SqlDbType.Int, CV.SanskarID());
            _sqlDatabase.AddInParameter(dbCommand, "@DivisionName", SqlDbType.VarChar, division.DivisionName);
            _sqlDatabase.AddInParameter(dbCommand, "@StandardId", SqlDbType.Int, division.StandardId);
            _sqlDatabase.AddInParameter(dbCommand, "@StartDate", SqlDbType.DateTime, division.StartDate);
            _sqlDatabase.AddInParameter(dbCommand, "@EndDate", SqlDbType.DateTime, division.EndDate);
            return Convert.ToBoolean(_sqlDatabase.ExecuteNonQuery(dbCommand));
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            throw;
        }
    }

    #endregion

    #region Method : PR_Division_Update

    public bool PR_Division_Update(Division division)
    {
        try
        {
            DbCommand dbCommand = _sqlDatabase.GetStoredProcCommand("PR_Division_Update");

            //Add Paramter Into SP
            // _sqlDatabase.AddInParameter(dbCommand, "@SanskarID", SqlDbType.Int, CV.SanskarID());
            _sqlDatabase.AddInParameter(dbCommand, "@DivisionId", SqlDbType.Int, division.DivisionId);
            _sqlDatabase.AddInParameter(dbCommand, "@StandardId", SqlDbType.Int, division.StandardId);
            _sqlDatabase.AddInParameter(dbCommand, "@DivisionName", SqlDbType.VarChar, division.DivisionName);
            _sqlDatabase.AddInParameter(dbCommand, "@StartDate", SqlDbType.DateTime, division.StartDate);
            _sqlDatabase.AddInParameter(dbCommand, "@EndDate", SqlDbType.DateTime, division.EndDate);
            return Convert.ToBoolean(_sqlDatabase.ExecuteNonQuery(dbCommand));
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            throw;
        }
    }

    #endregion

    #region Method : PR_Division_Delete

    public bool PR_Division_Delete(int DivisionId)
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Division_Delete");
            _sqlDatabase.AddInParameter(cmd, "@DivisionId", SqlDbType.Int, DivisionId);
            // _sqlDatabase.AddInParameter(cmd, "@SanskarID", SqlDbType.Int, CV.SanskarID());
            return Convert.ToBoolean(_sqlDatabase.ExecuteNonQuery(cmd));
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            throw;
        }
    }

    #endregion

    #region Methos : PR_Division_SelectAll

    public List<Division> PR_Division_SelectAll()
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Division_SelectAll");
            // _sqlDatabase.AddInParameter(cmd, "SanskarID", SqlDbType.Int, CV.SanskarID());
            List<Division> _divisions = new List<Division>();
            using (IDataReader idr = _sqlDatabase.ExecuteReader(cmd))
            {
                while (idr.Read())
                {
                    Division _dv = new Division();
                    _dv.DivisionId = Convert.ToInt32(idr["DivisionId"]);
                    // _dv.ClassesId = Convert.ToInt32(idr["ClassesId"]);
                    _dv.StandardId = Convert.ToInt32(idr["StandardId"]);
                    _dv.StandardName = idr["StandardName"].ToString();
                    _dv.DivisionName = idr["DivisionName"].ToString();
                    _dv.StartDate = idr["StartDate"] != DBNull.Value
                        ? Convert.ToDateTime(idr["StartDate"])
                        : (DateTime.Now);
                    _dv.EndDate = idr["EndDate"] != DBNull.Value
                        ? Convert.ToDateTime(idr["EndDate"])
                        : (DateTime.Now);
                    _dv.CreatedAt = idr["CreatedAt"] != DBNull.Value
                        ? Convert.ToDateTime(idr["CreatedAt"])
                        : (DateTime.Now);
                    _dv.ModifiedAt = idr["ModifiedAt"] != DBNull.Value
                        ? Convert.ToDateTime(idr["ModifiedAt"])
                        : (DateTime.Now);

                    _divisions.Add(_dv);
                }
            }

            return _divisions;
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Method : PR_Division_SelectByPK

    public Division PR_Division_SelectByPK(int DivisionId)
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Division_SelectByPK");
            // _sqlDatabase.AddInParameter(cmd, "SanskarID", SqlDbType.Int, CV.SanskarID());
            _sqlDatabase.AddInParameter(cmd, "DivisionId", SqlDbType.Int, DivisionId);
            Division division = null;
            using (IDataReader idr = _sqlDatabase.ExecuteReader(cmd))
            {
                if (idr.Read())
                {
                    division = new Division()
                    {
                        DivisionId = Convert.ToInt32(idr["DivisionId"]),
                        // ClassesId = Convert.ToInt32(idr["ClassesId"]),
                        StandardId = Convert.ToInt32(idr["StandardId"]),
                        DivisionName = idr["DivisionName"].ToString(),
                        StartDate = idr["StartDate"] != DBNull.Value
                            ? Convert.ToDateTime(idr["StartDate"])
                            : (DateTime.Now),
                        EndDate = idr["EndDate"] != DBNull.Value
                            ? Convert.ToDateTime(idr["EndDate"])
                            : (DateTime.Now),
                        CreatedAt = idr["CreatedAt"] != DBNull.Value
                            ? Convert.ToDateTime(idr["CreatedAt"])
                            : (DateTime.Now),
                        ModifiedAt = idr["ModifiedAt"] != DBNull.Value
                            ? Convert.ToDateTime(idr["ModifiedAt"])
                            : (DateTime.Now)
                    };
                }
            }

            return division;
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            throw;
        }
    }

    #endregion

    #region PR_Standard_DropDown

    public List<Standard> PR_Standard_DropDown()
    {
        List<Standard> Standard = new List<Standard>();
        try
        {
            using (DbCommand dbCommand = _sqlDatabase.GetStoredProcCommand("PR_Standard_DropDown"))
            {
                // _sqlDatabase.AddInParameter(dbCommand, "@SanskarID", DbType.Int32, CV.SanskarID());
                using (IDataReader dataReader = _sqlDatabase.ExecuteReader(dbCommand))
                {
                    while (dataReader.Read())
                    {
                        Standard standard = new Standard();
                        standard.StandardId = Convert.ToInt32(dataReader["StandardId"]);
                        standard.StandardName = dataReader["StandardName"].ToString();
                        Standard.Add(standard);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw;
        }

        return Standard;
    }

    #endregion
}