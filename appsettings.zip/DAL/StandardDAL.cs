﻿using System.Data;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using Sanskar_Admin.BAL;
using Sanskar_Admin.Models;

namespace Sanskar_Admin.DAL;

public class StandardDAL : DAL_Helper
{
    #region Configurations

    private static SqlDatabase _sqlDatabase;

    public StandardDAL()
    {
        _sqlDatabase = new SqlDatabase(ConnStr);
    }

    #endregion

    #region Method : PR_Standard_Insert

    public bool PR_Standard_Insert(Standard standard)
    {
        try
        {
            DbCommand dbCommand = _sqlDatabase.GetStoredProcCommand("PR_Standard_Insert");

            //Add Paramter Into SP
            _sqlDatabase.AddInParameter(dbCommand, "@StandardName", SqlDbType.VarChar, standard.StandardName);
            // _sqlDatabase.AddInParameter(dbCommand, "@SanskarID", SqlDbType.Int, CV.SanskarID());
            return Convert.ToBoolean(_sqlDatabase.ExecuteNonQuery(dbCommand));
        }
        catch (Exception ex)
        {
            return false;
        }
    }

    #endregion

    #region Method : PR_Standard_Delete

    public bool PR_Standard_Delete(int standardId)
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Standard_Delete");
            _sqlDatabase.AddInParameter(cmd, "@StandardId", SqlDbType.Int, standardId);
            // _sqlDatabase.AddInParameter(cmd, "@SanskarID", SqlDbType.Int, CV.SanskarID());
            return Convert.ToBoolean(_sqlDatabase.ExecuteNonQuery(cmd));
        }
        catch (Exception ex)
        {
            return false;
        }
    }

    #endregion

    #region Method : PR_Standard_Update

    public bool PR_Standard_Update(Standard standard)
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Standard_Update");
            _sqlDatabase.AddInParameter(cmd, "@StandardId", SqlDbType.Int, standard.StandardId);
            // _sqlDatabase.AddInParameter(cmd, "@SanskarID", SqlDbType.Int, CV.SanskarID());
            _sqlDatabase.AddInParameter(cmd, "@StandardName", SqlDbType.VarChar, standard.StandardName);
            return Convert.ToBoolean(_sqlDatabase.ExecuteNonQuery(cmd));
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            throw;
        }
    }

    #endregion

    #region Method : PR_Standard_SelectAll

    public List<Standard> PR_Standard_SelectAll()
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Standard_SelectAll");
            // _sqlDatabase.AddInParameter(cmd, "SanskarID", SqlDbType.Int, CV.SanskarID());
            List<Standard> _standards = new List<Standard>();
            using (IDataReader idr = _sqlDatabase.ExecuteReader(cmd))
            {
                while (idr.Read())
                {
                    Standard _sd = new Standard();
                    _sd.StandardId = Convert.ToInt32(idr["StandardId"]);
                    //_sd.SanskarID = Convert.ToInt32(idr["SanskarID"]);
                    _sd.StandardName = idr["StandardName"].ToString();
                    
                    _sd.CreatedAt = idr["CreatedAt"] != DBNull.Value
                        ? Convert.ToDateTime(idr["CreatedAt"])
                        : (DateTime?)null;
                    _sd.ModifiedAt = idr["ModifiedAt"] != DBNull.Value
                        ? Convert.ToDateTime(idr["ModifiedAt"])
                        : (DateTime?)null;

                    _standards.Add(_sd);
                }
            }

            return _standards;
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    #endregion

    #region Method : PR_Standard_SelectByPK

    public Standard PR_Standard_SelectByPK(int StandardId)
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Standard_SelectByPK");
            _sqlDatabase.AddInParameter(cmd, "StandardId", SqlDbType.Int, StandardId);
            //_sqlDatabase.AddInParameter(cmd, "SanskarID", SqlDbType.Int, CV.SanskarID());
            Standard standard = null;
            using (IDataReader idr = _sqlDatabase.ExecuteReader(cmd))
            {
                if (idr.Read())
                {
                    standard = new Standard
                    {
                        StandardId = Convert.ToInt32(idr["StandardId"]),
                      //  SanskarID = Convert.ToInt32(idr["SanskarID"]),
                        StandardName = idr["StandardName"].ToString(),

                        CreatedAt = idr["CreatedAt"] != DBNull.Value
                            ? Convert.ToDateTime(idr["CreatedAt"])
                            : (DateTime?)null,
                        ModifiedAt = idr["ModifiedAt"] != DBNull.Value
                            ? Convert.ToDateTime(idr["ModifiedAt"])
                            : (DateTime?)null
                    };
                }
            }

            return standard;
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    #endregion
}