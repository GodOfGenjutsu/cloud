﻿using System.Data;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using Sanskar_Admin.DAL;
using Sanskar_Admin.Models;

public class AttendanceDAL : DAL_Helper
{
    #region Configuration
    private static SqlDatabase _sqlDatabase;

    public AttendanceDAL()
    {
        _sqlDatabase = new SqlDatabase(ConnStr);
    }
    #endregion
    
    #region PR_Attendance_SelectByDate
    public List<Attendance> PR_Attendance_SelectByDate(DateTime date, int standardId, int divisionId)
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Attendance_SelectByDate");
            _sqlDatabase.AddInParameter(cmd, "@Date", SqlDbType.Date, date);
            _sqlDatabase.AddInParameter(cmd, "@StandardId", SqlDbType.Int, standardId);
            _sqlDatabase.AddInParameter(cmd, "@DivisionId", SqlDbType.Int, divisionId);

            List<Attendance> attendances = new List<Attendance>();

            using (IDataReader idr = _sqlDatabase.ExecuteReader(cmd))
            {
                while (idr.Read())
                {
                    Attendance attendance = new Attendance
                    {
                        AttendanceId = Convert.ToInt32(idr["AttendanceId"]),
                        StudentId = Convert.ToInt32(idr["StudentId"]),
                        StudentName = idr["StudentName"].ToString(),
                        StandardId = Convert.ToInt32(idr["StandardId"]),
                        StandardName = idr["StandardName"].ToString(),
                        DivisionId = Convert.ToInt32(idr["DivisionId"]),
                        DivisionName = idr["DivisionName"].ToString(),
                        AttendanceDate = Convert.ToDateTime(idr["AttendanceDate"]),
                        IsPresent = Convert.ToBoolean(idr["IsPresent"]),
                        StudentRollNumber = Convert.ToInt32(idr["StudentRollNumber"])
                    };

                    attendances.Add(attendance);
                }
            }

            return attendances;
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            throw;
        }
    }
    #endregion

    #region PR_Attendance_SelectByStudentId
    public List<Attendance> PR_Attendance_SelectByStudentId(int studentId, DateTime startDate, DateTime endDate)
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Attendance_SelectByStudentId");
            _sqlDatabase.AddInParameter(cmd, "@StudentId", SqlDbType.Int, studentId);
            _sqlDatabase.AddInParameter(cmd, "@StartDate", SqlDbType.Date, startDate);
            _sqlDatabase.AddInParameter(cmd, "@EndDate", SqlDbType.Date, endDate);

            List<Attendance> attendances = new List<Attendance>();

            using (IDataReader idr = _sqlDatabase.ExecuteReader(cmd))
            {
                while (idr.Read())
                {
                    Attendance attendance = new Attendance
                    {
                        AttendanceId = Convert.ToInt32(idr["AttendanceId"]),
                        StudentId = Convert.ToInt32(idr["StudentId"]),
                        AttendanceDate = Convert.ToDateTime(idr["AttendanceDate"]),
                        IsPresent = Convert.ToBoolean(idr["IsPresent"])
                    };

                    attendances.Add(attendance);
                }
            }

            return attendances;
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            throw;
        }
    }
    #endregion

    #region PR_Attendance_Insert
    public bool PR_Attendance_Insert(List<Attendance> attendances)
    {
        try
        {
            foreach (var attendance in attendances)
            {
                DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Attendance_Insert");
                _sqlDatabase.AddInParameter(cmd, "@StudentId", SqlDbType.Int, attendance.StudentId);
                _sqlDatabase.AddInParameter(cmd, "@StandardId", SqlDbType.Int, attendance.StandardId);
                _sqlDatabase.AddInParameter(cmd, "@DivisionId", SqlDbType.Int, attendance.DivisionId);
                _sqlDatabase.AddInParameter(cmd, "@AttendanceDate", SqlDbType.Date, attendance.AttendanceDate);
                _sqlDatabase.AddInParameter(cmd, "@IsPresent", SqlDbType.Bit, attendance.IsPresent);
                _sqlDatabase.AddInParameter(cmd, "@StudentRollNumber", SqlDbType.Int, attendance.StudentRollNumber);

                _sqlDatabase.ExecuteNonQuery(cmd);
            }
            return true;
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            return false;
        }
    }
    #endregion

    #region PR_Attendance_Update
    public bool PR_Attendance_Update(List<Attendance> attendances)
    {
        try
        {
            foreach (var attendance in attendances)
            {
                DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Attendance_Update");
                _sqlDatabase.AddInParameter(cmd, "@AttendanceId", SqlDbType.Int, attendance.AttendanceId);
                _sqlDatabase.AddInParameter(cmd, "@IsPresent", SqlDbType.Bit, attendance.IsPresent);

                _sqlDatabase.ExecuteNonQuery(cmd);
            }
            return true;
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            return false;
        }
    }
    #endregion
}