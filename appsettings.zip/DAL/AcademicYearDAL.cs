﻿using System.Data;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using Sanskar_Admin.Models;

namespace Sanskar_Admin.DAL;

public class AcademicYearDAL : DAL_Helper
{
    #region Configuration

    private static SqlDatabase _sqlDatabase;

    public AcademicYearDAL()
    {
        _sqlDatabase = new SqlDatabase(ConnStr);
    }

    #endregion

    #region All Academic Year

    public List<AcademicYear> PR_AcademicYear_SelectAll()
    {
        try
        {
            List<AcademicYear> academicYears = new List<AcademicYear>();
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_AcademicYear_SelectAll");
            using (IDataReader idr = _sqlDatabase.ExecuteReader(cmd))
            {
                while (idr.Read())
                {
                    AcademicYear academicYear = new AcademicYear();
                    academicYear.AcademicYearId = Convert.ToInt32(idr["AcademicYearId"]);
                    academicYear.StartingMonth = Convert.ToDateTime(idr["StartingMonth"]);
                    academicYear.EndingMonth = Convert.ToDateTime(idr["EndingMonth"]);
                    academicYear.StartingYear = Convert.ToInt32(idr["StartingYear"]);
                    academicYear.EndingYear = Convert.ToInt32(idr["EndingYear"]);
                    academicYear.CreatedAt = Convert.ToDateTime(idr["CreatedAt"]);
                    // You can add ModifiedAt if needed
                    academicYears.Add(academicYear);
                }
            }

            return academicYears;
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            throw;
        }
    }

    #endregion

    #region Select By ID

    public AcademicYear PR_AcademicYear_SelectById(int academicYearId)
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_AcademicYear_SelectById");
            _sqlDatabase.AddInParameter(cmd, "@AcademicYearId", SqlDbType.Int, academicYearId);
            AcademicYear academicYear = null;
            using (IDataReader idr = _sqlDatabase.ExecuteReader(cmd))
            {
                if (idr.Read())
                {
                    academicYear = new AcademicYear()
                    {
                        AcademicYearId = Convert.ToInt32(idr["AcademicYearId"]),
                        StartingMonth = Convert.ToDateTime(idr["StartingMonth"]),
                        EndingMonth = Convert.ToDateTime(idr["EndingMonth"]),
                        StartingYear = Convert.ToInt32(idr["StartingYear"]),
                        EndingYear = Convert.ToInt32(idr["EndingYear"]),
                        CreatedAt = Convert.ToDateTime(idr["CreatedAt"]),
                        ModifiedAt = idr["ModifiedAt"] != DBNull.Value
                            ? Convert.ToDateTime(idr["ModifiedAt"])
                            : (DateTime?)null
                    };
                }
            }

            return academicYear;
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            throw;
        }
    }

    #endregion

    #region Insert

    public bool PR_AcademicYear_Insert(AcademicYear academicYear)
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_AcademicYear_Insert");
            _sqlDatabase.AddInParameter(cmd, "@StartingMonth", SqlDbType.DateTime2, academicYear.StartingMonth);
            _sqlDatabase.AddInParameter(cmd, "@EndingMonth", SqlDbType.DateTime2, academicYear.EndingMonth);
            // _sqlDatabase.AddInParameter(cmd, "@ClassesId", SqlDbType.Int, 1);
            _sqlDatabase.AddInParameter(cmd, "@StartingYear", SqlDbType.Int, academicYear.StartingYear);
            _sqlDatabase.AddInParameter(cmd, "@EndingYear", SqlDbType.Int, academicYear.EndingYear);
            // You can add ModifiedAt if needed
            return Convert.ToBoolean(_sqlDatabase.ExecuteNonQuery(cmd));
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            throw;
        }
    }

    #endregion

    #region Update

    public bool PR_AcademicYear_Update(AcademicYear academicYear)
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_AcademicYear_Update");
            _sqlDatabase.AddInParameter(cmd, "@AcademicYearId", SqlDbType.Int, academicYear.AcademicYearId);
            _sqlDatabase.AddInParameter(cmd, "@StartingMonth", SqlDbType.DateTime2, academicYear.StartingMonth);
            _sqlDatabase.AddInParameter(cmd, "@EndingMonth", SqlDbType.DateTime2, academicYear.EndingMonth);
            _sqlDatabase.AddInParameter(cmd, "@StartingYear", SqlDbType.Int, academicYear.StartingYear);
            _sqlDatabase.AddInParameter(cmd, "@EndingYear", SqlDbType.Int, academicYear.EndingYear);
            // _sqlDatabase.AddInParameter(cmd, "@ClassesId", SqlDbType.Int,1); // Assuming you're updating ModifiedAt
            return Convert.ToBoolean(_sqlDatabase.ExecuteNonQuery(cmd));
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            throw;
        }
    }

    #endregion

    #region Delete

    public bool PR_AcademicYear_Delete(int academicYearId)
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_AcademicYear_Delete");
            _sqlDatabase.AddInParameter(cmd, "@AcademicYearId", SqlDbType.Int, academicYearId);
            return Convert.ToBoolean(_sqlDatabase.ExecuteNonQuery(cmd));
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            throw;
        }
    }

    #endregion
}