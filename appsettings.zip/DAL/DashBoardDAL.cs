﻿using System.Data;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using Sanskar_Admin.BAL;
using Sanskar_Admin.Models;

namespace Sanskar_Admin.DAL;

public class DashBoardDAL : DAL_Helper
{
    #region Config

    private static SqlDatabase _sqlDatabase;
    private string _connectionString;

    public DashBoardDAL()
    {
        _sqlDatabase = new SqlDatabase(ConnStr);
    }

    #endregion

    #region Method: PR_DashBoard_Conunt

    public DashboardViewModel PR_DashBoard_Conunt()
    {
        DashboardViewModel viewModel = new DashboardViewModel();

        try
        {
            DbCommand dbCommand = _sqlDatabase.GetStoredProcCommand("PR_DashBoard_Conunt");
            // _sqlDatabase.AddInParameter(dbCommand, "@ClassesId", DbType.Int32, CV.SanskarID());
        Console.WriteLine($"CV: {CV.SanskarID()}");
            using (IDataReader reader = _sqlDatabase.ExecuteReader(dbCommand))
            {
                if (reader.Read())
                {
                    viewModel.NumberOfInquiries = Convert.ToInt32(reader["Number of Inquiries"]);
                    viewModel.NumberOfStaff = Convert.ToInt32(reader["Number of Staff"]);
                    viewModel.NumberOfStudents = Convert.ToInt32(reader["Number of Students"]);
                }
            }
             Console.WriteLine("\n=== Dashboard Statistics ===");
        Console.WriteLine($"Number of Inquiries: {viewModel.NumberOfInquiries}");
        Console.WriteLine($"Number of Staff: {viewModel.NumberOfStaff}");
        Console.WriteLine($"Number of Students: {viewModel.NumberOfStudents}");
            viewModel.Inquiries = DashBoard_Inquiry_SelectAll();
            
            return viewModel;
        }
        catch (Exception ex)
        {
            return null;
        }
    }

    #endregion

    #region Select All

    public List<Inquiry> DashBoard_Inquiry_SelectAll()
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("DashBoard_Inquiry_SelectAll");
            // _sqlDatabase.AddInParameter(cmd, "ClassesId", SqlDbType.Int, CV.SanskarID());
            List<Inquiry> list = new List<Inquiry>();
            using (IDataReader dr = _sqlDatabase.ExecuteReader(cmd))
            {
                while (dr.Read())
                {
                    Inquiry pm = new Inquiry();
                    pm.InquiryId = Convert.ToInt32(dr["InquiryId"].ToString());
                    pm.StudentFirstName = dr["StudentFirstName"].ToString();
                    pm.StudentMiddleName = dr["StudentMiddleName"].ToString();
                    pm.StudentLastName = dr["StudentLastName"].ToString();
                    pm.ParentContact = dr["ParentContact"].ToString();
                    pm.StudentContact = dr["StudentContact"].ToString();
                    pm.Email = dr["Email"].ToString();
                    pm.Address = dr["Address"].ToString();
                    pm.InquiryDescription = dr["InquiryDescription"].ToString();
                    pm.Gender = dr["Gender"].ToString();
                    pm.FatherName = dr["FatherName"].ToString();
                    pm.MotherName = dr["MotherName"].ToString();
                    pm.StandardName = dr["StandardName"].ToString();
                    pm.Status = dr["Status"].ToString();
                    pm.CreatedAt = Convert.ToDateTime(dr["CreatedAt"].ToString());
                    list.Add(pm);
                }
            }

            return list;
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion
}