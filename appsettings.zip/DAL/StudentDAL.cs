﻿using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using Sanskar_Admin.BAL;
using Sanskar_Admin.Models;

namespace Sanskar_Admin.DAL;

public class StudentDAL : DAL_Helper
{
    #region Configuration

    private static SqlDatabase _sqlDatabase;

    public StudentDAL()
    {
        _sqlDatabase = new SqlDatabase(ConnStr);
    }

    #endregion

    #region Select All

    public List<Student> PR_Student_SelectAll()
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Student_SelectAll");
            // _sqlDatabase.AddInParameter(cmd, "ClassesId", SqlDbType.Int, CV.SanskarID());

            List<Student> _students = new List<Student>();

            using (IDataReader idr = _sqlDatabase.ExecuteReader(cmd))
            {
                while (idr.Read())
                {
                    Student obj = new Student();

                    obj.StudentId = Convert.ToInt32(idr["StudentId"]);
                    obj.StandardId = Convert.ToInt32(idr["StandardId"]);
                    obj.StandardName = idr["StandardId"].ToString();
                    obj.DivisionId = Convert.ToInt32(idr["DivisionId"]);
                    obj.DivisionName = idr["DivisionName"].ToString();
                    // obj.ClassesId = Convert.ToInt32(idr["ClassesId"]);
                    // obj.AuthenticationId = Convert.ToInt32(idr["AuthenticationId"]);
                    obj.BoardId = Convert.ToInt32(idr["BoardId"]);
                    obj.BoardName = idr["BoardName"].ToString();
                    obj.MediumId = Convert.ToInt32(idr["MediumId"]);
                    obj.MediumName = idr["MediumName"].ToString();
                    obj.StudentFirstName = idr["StudentFirstName"].ToString();
                    obj.StudentMiddleName = idr["StudentMiddleName"].ToString();
                    obj.StudentLastName = idr["StudentLastName"].ToString();
                    obj.FatherName = idr["FatherName"].ToString();
                    obj.MotherName = idr["MotherName"].ToString();
                    obj.ParentContact = idr["ParentContact"].ToString();
                    obj.StudentContact = idr["StudentContact"].ToString();
                    obj.Email = idr["Email"].ToString();
                    obj.Address = idr["Address"].ToString();
                    obj.Password = idr["Password"].ToString();
                    obj.Gender = idr["Gender"].ToString();
                    obj.StudentRollNumber = Convert.ToInt32(idr["StudentRollNumber"]);
                    // Assuming CreatedAt and ModifiedAt are DateTime columns
                    obj.CreatedAt = idr["CreatedAt"] != DBNull.Value
                        ? Convert.ToDateTime(idr["CreatedAt"])
                        : (DateTime?)null;
                    obj.ModifiedAt = idr["ModifiedAt"] != DBNull.Value
                        ? Convert.ToDateTime(idr["ModifiedAt"])
                        : (DateTime?)null;

                    _students.Add(obj);
                }
            }

            return _students;
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Select By Id

    public Student PR_Student_SelectById(int studentId)
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Student_SelectById");
            _sqlDatabase.AddInParameter(cmd, "StudentId", SqlDbType.Int, studentId);

            Student student = null;

            using (IDataReader idr = _sqlDatabase.ExecuteReader(cmd))
            {
                if (idr.Read())
                {
                    student = new Student
                    {
                        StudentId = Convert.ToInt32(idr["StudentId"]),
                        StudentRollNumber = Convert.ToInt32(idr["StudentRollNumber"]),
                        StandardId = Convert.ToInt32(idr["StandardId"]),
                        StandardName = idr["StandardName"].ToString(),
                        DivisionId = Convert.ToInt32(idr["DivisionId"]),
                        DivisionName = idr["DivisionName"].ToString(),
                        // ClassesId = Convert.ToInt32(idr["ClassesId"]),
                        // SanskarName = idr["SanskarName"].ToString(),
                        MediumId = Convert.ToInt32(idr["MediumId"]),
                        MediumName = idr["MediumName"].ToString(),
                        BoardId = Convert.ToInt32(idr["BoardId"]),
                        BoardName = idr["BoardName"].ToString(),
                        StudentFirstName = idr["StudentFirstName"].ToString(),
                        StudentMiddleName = idr["StudentMiddleName"].ToString(),
                        StudentLastName = idr["StudentLastName"].ToString(),
                        FatherName = idr["FatherName"].ToString(),
                        MotherName = idr["MotherName"].ToString(),
                        ParentContact = idr["ParentContact"].ToString(),
                        StudentContact = idr["StudentContact"].ToString(),
                        Email = idr["Email"].ToString(),
                        Address = idr["Address"].ToString(),
                        Password = idr["Password"].ToString(),
                        Gender = idr["Gender"].ToString(),
                        CreatedAt = idr["CreatedAt"] != DBNull.Value
                            ? Convert.ToDateTime(idr["CreatedAt"])
                            : (DateTime?)null,
                        ModifiedAt = idr["ModifiedAt"] != DBNull.Value
                            ? Convert.ToDateTime(idr["ModifiedAt"])
                            : (DateTime?)null
                    };
                }
            }

            return student;
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Insert

    public bool PR_Student_Insert(Student student)
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Student_Insert");

            // Hash the password
            string hashedPassword = BCrypt.Net.BCrypt.HashPassword(student.Password);

            // Set parameters for the stored procedure
            _sqlDatabase.AddInParameter(cmd, "StandardId", SqlDbType.Int, student.StandardId);
            _sqlDatabase.AddInParameter(cmd, "DivisionId", SqlDbType.Int, student.DivisionId);
            // _sqlDatabase.AddInParameter(cmd, "ClassesId", SqlDbType.Int, CV.SanskarID());
            _sqlDatabase.AddInParameter(cmd, "BoardId", SqlDbType.Int, student.BoardId);
            _sqlDatabase.AddInParameter(cmd, "MediumId", SqlDbType.Int, student.MediumId);
            _sqlDatabase.AddInParameter(cmd, "StudentFirstName", SqlDbType.VarChar, student.StudentFirstName);
            _sqlDatabase.AddInParameter(cmd, "StudentMiddleName", SqlDbType.VarChar, student.StudentMiddleName);
            _sqlDatabase.AddInParameter(cmd, "StudentLastName", SqlDbType.VarChar, student.StudentLastName);
            _sqlDatabase.AddInParameter(cmd, "FatherName", SqlDbType.VarChar, student.FatherName);
            _sqlDatabase.AddInParameter(cmd, "MotherName", SqlDbType.VarChar, student.MotherName);
            _sqlDatabase.AddInParameter(cmd, "ParentContact", SqlDbType.VarChar, student.ParentContact);
            _sqlDatabase.AddInParameter(cmd, "StudentContact", SqlDbType.VarChar, student.StudentContact);
            _sqlDatabase.AddInParameter(cmd, "Email", SqlDbType.VarChar, student.Email);
            _sqlDatabase.AddInParameter(cmd, "Address", SqlDbType.VarChar, student.Address);
            _sqlDatabase.AddInParameter(cmd, "Password", SqlDbType.VarChar, hashedPassword); // Store hashed password
            _sqlDatabase.AddInParameter(cmd, "Gender", SqlDbType.VarChar, student.Gender);
            _sqlDatabase.AddInParameter(cmd, "StudentRollNumber", SqlDbType.Int, student.StudentRollNumber);
            return Convert.ToBoolean(_sqlDatabase.ExecuteNonQuery(cmd));
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Update

    public bool PR_Student_Update(Student student)
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Student_Update");

            // Hash the password if it's being updated
            string hashedPassword = BCrypt.Net.BCrypt.HashPassword(student.Password);

            // Set parameters for the stored procedure
            _sqlDatabase.AddInParameter(cmd, "StudentId", SqlDbType.Int, student.StudentId);
            _sqlDatabase.AddInParameter(cmd, "StandardId", SqlDbType.Int, student.StandardId);
            _sqlDatabase.AddInParameter(cmd, "DivisionId", SqlDbType.Int, student.DivisionId);
            // _sqlDatabase.AddInParameter(cmd, "ClassesId", SqlDbType.Int, student.ClassesId);
            _sqlDatabase.AddInParameter(cmd, "BoardId", SqlDbType.Int, student.BoardId);
            _sqlDatabase.AddInParameter(cmd, "MediumId", SqlDbType.Int, student.MediumId);
            _sqlDatabase.AddInParameter(cmd, "StudentFirstName", SqlDbType.VarChar, student.StudentFirstName);
            _sqlDatabase.AddInParameter(cmd, "StudentMiddleName", SqlDbType.VarChar, student.StudentMiddleName);
            _sqlDatabase.AddInParameter(cmd, "StudentLastName", SqlDbType.VarChar, student.StudentLastName);
            _sqlDatabase.AddInParameter(cmd, "FatherName", SqlDbType.VarChar, student.FatherName);
            _sqlDatabase.AddInParameter(cmd, "MotherName", SqlDbType.VarChar, student.MotherName);
            _sqlDatabase.AddInParameter(cmd, "ParentContact", SqlDbType.VarChar, student.ParentContact);
            _sqlDatabase.AddInParameter(cmd, "StudentContact", SqlDbType.VarChar, student.StudentContact);
            _sqlDatabase.AddInParameter(cmd, "Email", SqlDbType.VarChar, student.Email);
            _sqlDatabase.AddInParameter(cmd, "Address", SqlDbType.VarChar, student.Address);
            _sqlDatabase.AddInParameter(cmd, "Password", SqlDbType.VarChar, hashedPassword); // Store hashed password
            _sqlDatabase.AddInParameter(cmd, "Gender", SqlDbType.VarChar, student.Gender);
            _sqlDatabase.AddInParameter(cmd, "StudentRollNumber", SqlDbType.VarChar, student.StudentRollNumber);

            // Execute the stored procedure
            return Convert.ToBoolean(_sqlDatabase.ExecuteNonQuery(cmd));
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Delete

    public bool PR_Student_Delete(int studentId)
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Student_Delete");

            // Set parameters for the stored procedure
            _sqlDatabase.AddInParameter(cmd, "StudentId", SqlDbType.Int, studentId);

            // Execute the stored procedure
            return Convert.ToBoolean(_sqlDatabase.ExecuteNonQuery(cmd));
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Board DropDown

    public List<BoardDropDownModel> PR_Board_DropDownList()
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Board_DropDown");
            // _sqlDatabase.AddInParameter(cmd, "@ClassesId", SqlDbType.Int, CV.SanskarID());

            List<BoardDropDownModel> boardList = new List<BoardDropDownModel>();

            using (IDataReader idr = _sqlDatabase.ExecuteReader(cmd))
            {
                while (idr.Read())
                {
                    BoardDropDownModel board = new BoardDropDownModel
                    {
                        BoardId = Convert.ToInt32(idr["BoardId"]),
                        BoardName = idr["BoardName"].ToString()
                    };

                    boardList.Add(board);
                }
            }

            return boardList;
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Division DropDown

    public List<DivisionDropDownModel> PR_Division_DropDownList()
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Division_DropDown");
            // _sqlDatabase.AddInParameter(cmd, "@ClassesId", SqlDbType.Int, CV.SanskarID());

            List<DivisionDropDownModel> divisionList = new List<DivisionDropDownModel>();

            using (IDataReader idr = _sqlDatabase.ExecuteReader(cmd))
            {
                while (idr.Read())
                {
                    DivisionDropDownModel division = new DivisionDropDownModel
                    {
                        DivisionId = Convert.ToInt32(idr["DivisionId"]),
                        DivisionName = idr["DivisionName"].ToString()
                    };

                    divisionList.Add(division);
                }
            }

            return divisionList;
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Medium DropDown

    public List<MediumDropDownModel> PR_Medium_DropDownList()
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Medium_DropDown");
            // _sqlDatabase.AddInParameter(cmd, "@ClassesId", SqlDbType.Int, CV.SanskarID());

            List<MediumDropDownModel> mediumList = new List<MediumDropDownModel>();

            using (IDataReader idr = _sqlDatabase.ExecuteReader(cmd))
            {
                while (idr.Read())
                {
                    MediumDropDownModel medium = new MediumDropDownModel
                    {
                        MediumId = Convert.ToInt32(idr["MediumId"]),
                        MediumName = idr["MediumName"].ToString()
                    };

                    mediumList.Add(medium);
                }
            }

            return mediumList;
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Standard DropDown

    public List<StandardDropDownModel> PR_Standard_DropDownList()
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Standard_DropDown");
            // _sqlDatabase.AddInParameter(cmd, "@ClassesId", SqlDbType.Int, CV.SanskarID());

            List<StandardDropDownModel> standardList = new List<StandardDropDownModel>();

            using (IDataReader idr = _sqlDatabase.ExecuteReader(cmd))
            {
                while (idr.Read())
                {
                    StandardDropDownModel standard = new StandardDropDownModel
                    {
                        StandardId = Convert.ToInt32(idr["StandardId"]),
                        StandardName = idr["StandardName"].ToString()
                    };

                    standardList.Add(standard);
                }
            }

            return standardList;
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Academic DropDown

    public List<AcademicYearDropDown> PR_AcademicYear_DropDown()
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_AcademicYear_DropDown");
            // _sqlDatabase.AddInParameter(cmd, "@ClassesId", SqlDbType.Int, CV.SanskarID());

            List<AcademicYearDropDown> academicList = new List<AcademicYearDropDown>();

            using (IDataReader idr = _sqlDatabase.ExecuteReader(cmd))
            {
                while (idr.Read())
                {
                    AcademicYearDropDown standard = new AcademicYearDropDown
                    {
                        AcademicYearId = Convert.ToInt32(idr["AcademicYearId"]),
                        AcademicYear = idr["AcademicYear"].ToString()
                    };

                    academicList.Add(standard);
                }
            }

            return academicList;
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion
}