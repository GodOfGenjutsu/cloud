﻿using System.Data;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using Sanskar_Admin.Areas.Auth.Models;
using Sanskar_Admin.Models;

namespace Sanskar_Admin.DAL;

public class LoginDAL : DAL_Helper
{
    #region Configurations

    private static SqlDatabase _sqlDatabase;

    public LoginDAL()
    {
        _sqlDatabase = new SqlDatabase(ConnStr);
    }

    #endregion

    #region Method : Admin Login

    public Admin? PR_Admin_Login(Login model)
    {
        try
        {
            Admin? obj = null;
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Admin_Login");
            _sqlDatabase.AddInParameter(cmd, "Email", SqlDbType.VarChar, model.Email);
            // _sqlDatabase.AddInParameter(cmd, "Password", SqlDbType.VarChar, model.Password); // Remove plain text password

            using (IDataReader idr = _sqlDatabase.ExecuteReader(cmd))
            {
                if (idr.Read())
                {
                    string hashedPasswordFromDb = idr["Password"].ToString(); // Get hashed password from DB

                    // Verify the password
                    if (BCrypt.Net.BCrypt.Verify(model.Password, hashedPasswordFromDb))
                    {
                        obj = new Admin
                        {
                            AdminId = Convert.ToInt32(idr["AdminId"]),
                            AdminName = idr["AdminName"].ToString(),
                            ClassesId = Convert.ToInt32(idr["ClassesId"]),
                            Email = idr["Email"].ToString(),
                            ProfileImage = idr["ProfileImage"].ToString(),
                            Role = "Admin"
                        };
                    }
                }
            }

            return obj;
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Method: Staff Login

    public Staff? PR_Staff_Login(Login model)
    {
        try
        {
            // string hashedPassword = BCrypt.Net.BCrypt.HashPassword("881CIT30U6VacBi");
            // Console.WriteLine(hashedPassword);

            // Console.WriteLine(" ",);
            Staff? obj = null;
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Staff_Login");
            _sqlDatabase.AddInParameter(cmd, "Email", SqlDbType.VarChar, model.Email);
            //_sqlDatabase.AddInParameter(cmd, "Password", SqlDbType.VarChar, model.Password); // Remove plain text password

            using (IDataReader idr = _sqlDatabase.ExecuteReader(cmd))
            {
                if (idr.Read())
                {
                    string hashedPasswordFromDb = idr["Password"].ToString(); // Get hashed password from DB

                    // Verify the password
                    if (BCrypt.Net.BCrypt.Verify(model.Password, hashedPasswordFromDb))
                    {
                        obj = new Staff
                        {
                            StaffID = Convert.ToInt32(idr["StaffID"]),
                            StaffName = idr["StaffName"].ToString(),
                            // SanskarId = Convert.ToInt32(idr["SanskarID"]),
                            Email = idr["Email"].ToString(),
                            Role = idr["Role"].ToString()
                        };
                    }
                }
            }

            return obj;
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Method : Student login

    public Student? PR_Student_Login(Login model)
    {
        try
        {
            //PH4xKzRGqYs4sZL
            // string hashedPassword = BCrypt.Net.BCrypt.HashPassword("PH4xKzRGqYs4sZL");
            //dumdum@123D
            // string hashedPassword2 = BCrypt.Net.BCrypt.HashPassword("dumdum@123D");
            // Console.WriteLine();
            Student? obj = null;
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Student_Login");
            _sqlDatabase.AddInParameter(cmd, "Email", SqlDbType.VarChar, model.Email);
            //_sqlDatabase.AddInParameter(cmd, "Password", SqlDbType.VarChar, model.Password); // Remove plain text password

            using (IDataReader idr = _sqlDatabase.ExecuteReader(cmd))
            {
                if (idr.Read())
                {
                    string hashedPasswordFromDb = idr["Password"].ToString(); // Get hashed password from DB

                    // Verify the password
                    if (BCrypt.Net.BCrypt.Verify(model.Password, hashedPasswordFromDb))
                    {
                        obj = new Student
                        {
                            StudentId = Convert.ToInt32(idr["StudentId"]),
                            StudentFirstName = idr["StudentFirstName"].ToString(),
                            Email = idr["Email"].ToString(),
                            Role = idr["Role"].ToString()
                        };
                    }
                }
            }

            return obj;
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion
}