namespace Sanskar_Admin.DAL;

public class DAL_Helper
{
    public static String ConnStr = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build().GetConnectionString("connectionString");
}