using System.Data;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using Sanskar_Admin.BAL;
using Sanskar_Admin.Models;

namespace Sanskar_Admin.DAL;

public class SubjectDAL : DAL_Helper
{
    #region Configurations

    private static SqlDatabase _sqlDatabase;

    public SubjectDAL()
    {
        _sqlDatabase = new SqlDatabase(ConnStr);
    }

    #endregion

    #region Method : PR_Subject_Insert

    public bool PR_Subject_Insert(Subject subject)
    {
        try
        {
            DbCommand dbCommand = _sqlDatabase.GetStoredProcCommand("PR_Subject_Insert");

            //Add Paramter Into SP
            // _sqlDatabase.AddInParameter(dbCommand, "@SanskarID", SqlDbType.Int, CV.SanskarID());
            _sqlDatabase.AddInParameter(dbCommand, "@BoardId", SqlDbType.Int, subject.BoardId);
            _sqlDatabase.AddInParameter(dbCommand, "@MediumId", SqlDbType.Int, subject.MediumId);
            _sqlDatabase.AddInParameter(dbCommand, "@StandardId", SqlDbType.Int, subject.StandardId);
            _sqlDatabase.AddInParameter(dbCommand, "@SubjectCode", SqlDbType.VarChar, subject.SubjectCode);
            _sqlDatabase.AddInParameter(dbCommand, "@SubjectName", SqlDbType.VarChar, subject.SubjectName);
            _sqlDatabase.AddInParameter(dbCommand, "@IsActive", SqlDbType.Bit, subject.IsActive);
            return Convert.ToBoolean(_sqlDatabase.ExecuteNonQuery(dbCommand));
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            throw;
        }
    }

    #endregion

    #region Method : PR_Subject_Update

    public bool PR_Subject_Update(Subject subject)
    {
        try
        {
            DbCommand dbCommand = _sqlDatabase.GetStoredProcCommand("PR_Subject_Update");
            //Add Paramter Into SP
            // _sqlDatabase.AddInParameter(dbCommand, "@SanskarID", SqlDbType.Int, CV.SanskarID());
            _sqlDatabase.AddInParameter(dbCommand, "@SubjectId", SqlDbType.Int, subject.SubjectId);
            _sqlDatabase.AddInParameter(dbCommand, "@BoardId", SqlDbType.Int, subject.BoardId);
            _sqlDatabase.AddInParameter(dbCommand, "@MediumId", SqlDbType.Int, subject.MediumId);
            _sqlDatabase.AddInParameter(dbCommand, "@StandardId", SqlDbType.Int, subject.StandardId);
            _sqlDatabase.AddInParameter(dbCommand, "@SubjectCode", SqlDbType.VarChar, subject.SubjectCode);
            _sqlDatabase.AddInParameter(dbCommand, "@SubjectName", SqlDbType.VarChar, subject.SubjectName);
            _sqlDatabase.AddInParameter(dbCommand, "@IsActive", SqlDbType.Bit, subject.IsActive);
            return Convert.ToBoolean(_sqlDatabase.ExecuteNonQuery(dbCommand));
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            throw;
        }
    }

    #endregion

    #region Method : PR_Subject_Delete

    public bool PR_Subject_Delete(int SubjectId)
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Subject_Delete");
            _sqlDatabase.AddInParameter(cmd, "@SubjectId", SqlDbType.Int, SubjectId);
            // _sqlDatabase.AddInParameter(cmd, "@SanskarID", SqlDbType.Int, CV.SanskarID());
            return Convert.ToBoolean(_sqlDatabase.ExecuteNonQuery(cmd));
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            throw;
        }
    }

    #endregion

    #region Methos : PR_Subject_SelectAll

    public List<Subject> PR_Subject_SelectAll()
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Subject_SelectAll");
            // _sqlDatabase.AddInParameter(cmd, "SanskarID", SqlDbType.Int, CV.SanskarID());
            List<Subject> _subjects = new List<Subject>();
            using (IDataReader idr = _sqlDatabase.ExecuteReader(cmd))
            {
                while (idr.Read())
                {
                    Subject _sb = new Subject();
                    _sb.SubjectId = Convert.ToInt32(idr["SubjectId"]);
                    _sb.BoardId = Convert.ToInt32(idr["BoardId"]);
                    _sb.BoardName = idr["BoardName"].ToString();
                    _sb.StandardId = Convert.ToInt32(idr["StandardId"]);
                    _sb.StandardName = idr["StandardName"].ToString();
                    _sb.MediumId = Convert.ToInt32(idr["MediumId"]);
                    _sb.MediumName = idr["MediumName"].ToString();
                    _sb.SubjectCode = idr["SubjectCode"].ToString();
                    _sb.SubjectName = idr["SubjectName"].ToString();
                    _sb.IsActive = Convert.ToBoolean(idr["IsActive"]);
                    _sb.CreatedAt = idr["CreatedAt"] != DBNull.Value
                        ? Convert.ToDateTime(idr["CreatedAt"])
                        : (DateTime.Now);
                    _sb.ModifiedAt = idr["ModifiedAt"] != DBNull.Value
                        ? Convert.ToDateTime(idr["ModifiedAt"])
                        : (DateTime.Now);
                    _subjects.Add(_sb);
                }
            }

            return _subjects;
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Method : PR_Subject_SelectById

    public Subject PR_Subject_SelectById(int SubjectId)
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Subject_SelectById");
            _sqlDatabase.AddInParameter(cmd, "SubjectId", SqlDbType.Int, SubjectId);
            // _sqlDatabase.AddInParameter(cmd, "SanskarID", SqlDbType.Int, CV.SanskarID());
            Subject subject = null;
            using (IDataReader idr = _sqlDatabase.ExecuteReader(cmd))
            {
                if (idr.Read())
                {
                    subject = new Subject()
                    {
                        SubjectId = Convert.ToInt32(idr["SubjectId"]),
                        BoardId = Convert.ToInt32(idr["BoardId"]),
                        StandardId = Convert.ToInt32(idr["StandardId"]),
                        MediumId = Convert.ToInt32(idr["MediumId"]),
                        SubjectCode = idr["SubjectCode"].ToString(),
                        SubjectName = idr["SubjectName"].ToString(),
                        IsActive = Convert.ToBoolean(idr["IsActive"]),
                        CreatedAt = idr["CreatedAt"] != DBNull.Value
                            ? Convert.ToDateTime(idr["CreatedAt"])
                            : (DateTime.Now),
                        ModifiedAt = idr["ModifiedAt"] != DBNull.Value
                            ? Convert.ToDateTime(idr["ModifiedAt"])
                            : (DateTime.Now),
                    };
                }
            }

            return subject;
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            throw;
        }
    }

    #endregion

    #region GetBoardDropdownList

    public List<BoardDropDownModel> GetBoardDropdownList()
    {
        List<BoardDropDownModel> Board = new List<BoardDropDownModel>();
        try
        {
            using (DbCommand dbCommand = _sqlDatabase.GetStoredProcCommand("PR_Board_DropDown"))
            {
                // _sqlDatabase.AddInParameter(dbCommand, "@SanskarID", DbType.Int32, CV.SanskarID());
                using (IDataReader dataReader = _sqlDatabase.ExecuteReader(dbCommand))
                {
                    while (dataReader.Read())
                    {
                        BoardDropDownModel board = new BoardDropDownModel();
                        board.BoardId = Convert.ToInt32(dataReader["BoardId"]);
                        board.BoardName = dataReader["BoardName"].ToString();
                        // Add more properties as needed

                        Board.Add(board);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw;
        }

        return Board;
    }

    #endregion

    #region GetStdDropdownList

    public List<StandardDropDownModel> GetStdDropdownList()
    {
        List<StandardDropDownModel> Standard = new List<StandardDropDownModel>();
        try
        {
            using (DbCommand dbCommand = _sqlDatabase.GetStoredProcCommand("PR_Standard_DropDown"))
            {
                // _sqlDatabase.AddInParameter(dbCommand, "@SanskarID", DbType.Int32, CV.SanskarID());
                using (IDataReader dataReader = _sqlDatabase.ExecuteReader(dbCommand))
                {
                    while (dataReader.Read())
                    {
                        StandardDropDownModel standard = new StandardDropDownModel();
                        standard.StandardId = Convert.ToInt32(dataReader["StandardId"]);
                        standard.StandardName = dataReader["StandardName"].ToString();
                        // Add more properties as needed

                        Standard.Add(standard);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw;
        }

        return Standard;
    }

    #endregion

    #region GetMediumDropdownList

    public List<MediumDropDownModel> GetMediumDropdownList()
    {
        List<MediumDropDownModel> Medium = new List<MediumDropDownModel>();
        try
        {
            using (DbCommand dbCommand = _sqlDatabase.GetStoredProcCommand("PR_Medium_DropDown"))
            {
                // _sqlDatabase.AddInParameter(dbCommand, "@SanskarID", DbType.Int32, CV.SanskarID());
                using (IDataReader dataReader = _sqlDatabase.ExecuteReader(dbCommand))
                {
                    while (dataReader.Read())
                    {
                        MediumDropDownModel medium = new MediumDropDownModel();
                        medium.MediumId = Convert.ToInt32(dataReader["MediumId"]);
                        medium.MediumName = dataReader["MediumName"].ToString();
                        Medium.Add(medium);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw;
        }

        return Medium;
    }

    #endregion
}