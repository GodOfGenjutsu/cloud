﻿// DAL/AdminProfileDAL.cs
using System.Data;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using Sanskar_Admin.BAL;
using Sanskar_Admin.Models;

namespace Sanskar_Admin.DAL;

public class AdminProfileDAL : DAL_Helper
{
    #region Configuration

    private static SqlDatabase _sqlDatabase;

    public AdminProfileDAL()
    {
        _sqlDatabase = new SqlDatabase(ConnStr);
    }

    #endregion

    #region AdminBy ID

    public AdminProfileViewModel AdminProfile_SelectByID()
    {
        try
        {
            AdminProfileViewModel obj = new AdminProfileViewModel();

            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Admin_SelectById");
            _sqlDatabase.AddInParameter(cmd, "AdminId", SqlDbType.Int, CV.UserID());
            IDataReader idr = _sqlDatabase.ExecuteReader(cmd);
            while (idr.Read())
            {
                obj.AdminId = Convert.ToInt32(idr["AdminId"]);
                obj.AdminName = idr["AdminName"].ToString();
                obj.ExistingProfileImage = idr["ProfileImage"].ToString();
                obj.Email = idr["Email"].ToString();
                obj.NewPassword = "";
                obj.ConfirmPassword = "";
            }
            return obj;
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion

    #region Profile Update

    public bool UpdateAdminProfile(AdminProfileViewModel model)
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Admin_UpdateProfile");
            _sqlDatabase.AddInParameter(cmd, "AdminId", SqlDbType.Int, model.AdminId);
            _sqlDatabase.AddInParameter(cmd, "Email", SqlDbType.VarChar, model.Email);

            // Hash the password if a new password is provided
            if (!string.IsNullOrEmpty(model.NewPassword))
            {
                // Hash the password using a secure hashing algorithm (e.g., BCrypt)
                string hashedPassword = BCrypt.Net.BCrypt.HashPassword(model.NewPassword);
                _sqlDatabase.AddInParameter(cmd, "Password", SqlDbType.VarChar, hashedPassword);
            }
            else
            {
                // If no new password is provided, pass a null value to the stored procedure
                _sqlDatabase.AddInParameter(cmd, "Password", SqlDbType.VarChar, DBNull.Value);
            }

            _sqlDatabase.AddInParameter(cmd, "ProfileImage", SqlDbType.VarChar, model.ExistingProfileImage);
            // _sqlDatabase.AddInParameter(cmd, "ModifiedAt", SqlDbType.DateTime, DateTime.Now);

            return _sqlDatabase.ExecuteNonQuery(cmd) > 0;
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            return false;
        }
    }

    #endregion
}