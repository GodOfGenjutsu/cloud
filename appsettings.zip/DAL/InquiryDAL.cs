﻿using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System.Data.Common;
using System.Data;
using System.Data.SqlClient;
using Sanskar_Admin.BAL;
using Sanskar_Admin.Models;

namespace Sanskar_Admin.DAL;

public class InquiryDAL : DAL_Helper
{
    #region Configurations

    private static SqlDatabase _sqlDatabase;
    private string _connectionString;

    public InquiryDAL()
    {
        _sqlDatabase = new SqlDatabase(ConnStr);
    }

    #endregion

    #region PR_INQUIRY_SELECTALL

    public List<Inquiry> PR_Inquiry_SelectAll()
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Inquiry_SelectAll");
            // _sqlDatabase.AddInParameter(cmd, "@ClassId", SqlDbType.Int, CV.SanskarID());
            List<Inquiry> list = new List<Inquiry>();

            using (IDataReader dr = _sqlDatabase.ExecuteReader(cmd))
            {
                while (dr.Read())
                {
                    Inquiry pm = new Inquiry();
                    pm.InquiryId = Convert.ToInt32(dr["InquiryId"].ToString());
                    pm.StudentFirstName = dr["StudentFirstName"].ToString();
                    pm.StudentMiddleName = dr["StudentMiddleName"].ToString();
                    pm.StudentLastName = dr["StudentLastName"].ToString();
                    pm.ParentContact = dr["ParentContact"].ToString();
                    pm.StudentContact = dr["StudentContact"].ToString();
                    pm.Email = dr["Email"].ToString();
                    pm.Address = dr["Address"].ToString();
                    pm.InquiryDescription = dr["InquiryDescription"].ToString();
                    pm.Gender = dr["Gender"].ToString();
                    pm.FatherName = dr["FatherName"].ToString();
                    pm.MotherName = dr["MotherName"].ToString();
                    pm.CreatedAt = Convert.ToDateTime(dr["CreatedAt"].ToString());
                    list.Add(pm);
                }
            }

            return list;
        }
        catch
        {
            return null;
        }
    }

    #endregion

    #region PR_Inquiry_SelectByPK

    public Inquiry PR_Inquiry_SelectByPK(int InquiryID)
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Inquiry_SelectByPK");
            _sqlDatabase.AddInParameter(cmd, "@InquiryID", SqlDbType.Int, InquiryID);
            // sqlDatabase.AddInParameter(cmd, "@ClassesId", SqlDbType.Int, CV.SanskarID());
            Inquiry inquiry = new Inquiry();

            using (IDataReader dr = _sqlDatabase.ExecuteReader(cmd))
            {
                while (dr.Read())
                {
                    inquiry.InquiryId = Convert.ToInt32(dr["InquiryId"].ToString());
                    // inquiry.ClassesId = Convert.ToInt32(dr["ClassesId"].ToString());
                    inquiry.StudentFirstName = dr["StudentFirstName"].ToString();
                    inquiry.StudentMiddleName = dr["StudentMiddleName"].ToString();
                    inquiry.StudentLastName = dr["StudentLastName"].ToString();
                    inquiry.ParentContact = dr["ParentContact"].ToString();
                    inquiry.StudentContact = dr["StudentContact"].ToString();
                    inquiry.Email = dr["Email"].ToString();
                    inquiry.Address = dr["Address"].ToString();
                    inquiry.InquiryDescription = dr["InquiryDescription"].ToString();
                    inquiry.Gender = dr["Gender"].ToString();
                    inquiry.FatherName = dr["FatherName"].ToString();
                    inquiry.MotherName = dr["MotherName"].ToString();
                    inquiry.BoardId = Convert.ToInt32(dr["BoardId"].ToString());
                    inquiry.BoardName = dr["BoardName"].ToString();
                    inquiry.StandardId = Convert.ToInt32(dr["StandardId"].ToString());
                    inquiry.StandardName = dr["StandardName"].ToString();
                    inquiry.MediumId = Convert.ToInt32(dr["MediumId"].ToString());
                    inquiry.MediumName = dr["MediumName"].ToString();
                }
            }

            return inquiry;
        }
        catch (Exception ex)
        {
            return null;
        }
    }

    #endregion

    #region Method : PR_Inquiry_Insert

    public bool PR_Inquiry_Insert(Inquiry inquiryModel)
    {
        try
        {
            DbCommand dbCommand = _sqlDatabase.GetStoredProcCommand("PR_Inquiry_Insert");
            _sqlDatabase.AddInParameter(dbCommand, "@BoardId", DbType.Int32, inquiryModel.BoardId);
            _sqlDatabase.AddInParameter(dbCommand, "@MediumId", DbType.Int32, inquiryModel.MediumId);
            // _sqlDatabase.AddInParameter(dbCommand, "@ClassesId", DbType.Int32, 1);
            _sqlDatabase.AddInParameter(dbCommand, "@StandardId", DbType.Int32, inquiryModel.StandardId);
            _sqlDatabase.AddInParameter(dbCommand, "@StudentFirstName", SqlDbType.VarChar,
                inquiryModel.StudentFirstName);
            _sqlDatabase.AddInParameter(dbCommand, "@StudentMiddleName", SqlDbType.VarChar,
                inquiryModel.StudentMiddleName);
            _sqlDatabase.AddInParameter(dbCommand, "@StudentLastName", SqlDbType.VarChar,
                inquiryModel.StudentLastName);
            _sqlDatabase.AddInParameter(dbCommand, "@FatherName", SqlDbType.VarChar, inquiryModel.FatherName);
            _sqlDatabase.AddInParameter(dbCommand, "@MotherName", SqlDbType.VarChar, inquiryModel.MotherName);
            _sqlDatabase.AddInParameter(dbCommand, "@ParentContact", SqlDbType.VarChar, inquiryModel.ParentContact);
            _sqlDatabase.AddInParameter(dbCommand, "@StudentContact", SqlDbType.VarChar,
                inquiryModel.StudentContact);
            _sqlDatabase.AddInParameter(dbCommand, "@Email", SqlDbType.VarChar, inquiryModel.Email);
            _sqlDatabase.AddInParameter(dbCommand, "@Address", SqlDbType.VarChar, inquiryModel.Address);
            _sqlDatabase.AddInParameter(dbCommand, "@InquiryDescription", SqlDbType.VarChar,
                inquiryModel.InquiryDescription);
            _sqlDatabase.AddInParameter(dbCommand, "@Gender", SqlDbType.VarChar, inquiryModel.Gender);


            return Convert.ToBoolean(_sqlDatabase.ExecuteNonQuery(dbCommand));
        }
        catch (Exception ex)
        {
            return false;
        }
    }

    #endregion

    #region Method : PR_Inquiry_Delete

    public bool PR_Inquiry_Delete(int InquiryID)
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Inquiry_Delete");
            _sqlDatabase.AddInParameter(cmd, "@InquiryID", SqlDbType.Int, InquiryID);

            // Execute the deletion command
            int rowsAffected = _sqlDatabase.ExecuteNonQuery(cmd);

            // Check if any rows were affected (indicating a successful deletion)
            return rowsAffected > 0;
        }
        catch (Exception ex)
        {
            // Log or handle the exception as needed
            return false;
        }
    }

    #endregion


    #region GetBoardsDLL

    public List<Board> GetBoardsDLL()
    {
        List<Board> boards = new List<Board>();

        try
        {
            // Execute SQL command to fetch boards from the database
            using (DbCommand dbCommand = _sqlDatabase.GetStoredProcCommand("PR_Board_DropDown"))
            {
                // _sqlDatabase.AddInParameter(dbCommand, "@ClassesId", SqlDbType.Int, 1);

                using (IDataReader dataReader = _sqlDatabase.ExecuteReader(dbCommand))
                {
                    while (dataReader.Read())
                    {
                        Board board = new Board();
                        board.BoardId = Convert.ToInt32(dataReader["BoardId"]);
                        board.BoardName = dataReader["BoardName"].ToString();
                        // Add more properties as needed

                        boards.Add(board);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            // Log or handle the exception
            // For simplicity, let's rethrow the exception
            throw;
        }

        return boards;
    }

    #endregion

    #region GetMediumsDLL

    public List<Medium> GetMediumsDLL()
    {
        List<Medium> mediums = new List<Medium>();

        try
        {
            // Execute SQL command to fetch mediums from the database
            using (DbCommand dbCommand = _sqlDatabase.GetStoredProcCommand("PR_Medium_DropDown"))
            {
                // _sqlDatabase.AddInParameter(dbCommand, "@ClassesId", SqlDbType.Int, 1);
                using (IDataReader dataReader = _sqlDatabase.ExecuteReader(dbCommand))
                {
                    while (dataReader.Read())
                    {
                        Medium medium = new Medium();
                        medium.MediumId = Convert.ToInt32(dataReader["MediumId"]);
                        medium.MediumName = dataReader["MediumName"].ToString();
                        // Add more properties as needed

                        mediums.Add(medium);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            // Log or handle the exception
            // For simplicity, let's rethrow the exception
            throw;
        }

        return mediums;
    }

    #endregion

    #region GetStandardsDLL

    public List<Standard> GetStandardsDLL()
    {
        List<Standard> standards = new List<Standard>();

        try
        {
            // Execute SQL command to fetch standards from the database
            using (DbCommand dbCommand = _sqlDatabase.GetStoredProcCommand("PR_Standard_DropDown"))
            {
                // _sqlDatabase.AddInParameter(dbCommand, "@ClassesId", SqlDbType.Int, 1);
                using (IDataReader dataReader = _sqlDatabase.ExecuteReader(dbCommand))
                {
                    while (dataReader.Read())
                    {
                        Standard standard = new Standard();
                        standard.StandardId = Convert.ToInt32(dataReader["StandardId"]);
                        standard.StandardName = dataReader["StandardName"].ToString();
                        // Add more properties as needed

                        standards.Add(standard);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            // Log or handle the exception
            // For simplicity, let's rethrow the exception
            throw;
        }

        return standards;
    }

    #endregion

}