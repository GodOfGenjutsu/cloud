﻿using Sanskar_Admin.Models;
using System.Data.Common;
using System.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using Sanskar_Admin.BAL;

namespace Sanskar_Admin.DAL;

public class BoardDAL : DAL_Helper
{
    #region Configuration

    private static SqlDatabase _sqlDatabase;

    public BoardDAL()
    {
        _sqlDatabase = new SqlDatabase(ConnStr);
    }

    #endregion

    #region Method : PR_Board_Insert

    public bool PR_Board_Insert(Board board)
    {
        try
        {
            DbCommand dbCommand = _sqlDatabase.GetStoredProcCommand("PR_Board_Insert");

            //Add Parameter Into SP
            // _sqlDatabase.AddInParameter(dbCommand, "@ClassesId", SqlDbType.Int, 1);
            _sqlDatabase.AddInParameter(dbCommand, "@BoardName", SqlDbType.VarChar, board.BoardName);
            return Convert.ToBoolean(_sqlDatabase.ExecuteNonQuery(dbCommand));
        }
        catch (Exception ex)
        {
            return false;
        }
    }

    #endregion

    #region Method : PR_Board_Update

    public bool PR_Board_Update(Board board)
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Board_Update");
            // _sqlDatabase.AddInParameter(cmd, "@SanskarID", SqlDbType.Int, 1);
            _sqlDatabase.AddInParameter(cmd, "BoardId", SqlDbType.Int, board.BoardId);
            _sqlDatabase.AddInParameter(cmd, "BoardName", SqlDbType.VarChar, board.BoardName);

            //Execute the Query
            return Convert.ToBoolean(_sqlDatabase.ExecuteNonQuery(cmd));
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    #endregion

    #region Method : PR_Board_Delete

    public bool PR_Board_Delete(int boardId)
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Board_Delete");

            // Set parameters for the sp
            _sqlDatabase.AddInParameter(cmd, "BoardId", SqlDbType.Int, boardId);
            // _sqlDatabase.AddInParameter(cmd, "@SanskarID", SqlDbType.Int, 1);

            // Execute the SP
            return Convert.ToBoolean(_sqlDatabase.ExecuteNonQuery(cmd));
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    #endregion

    #region method : PR_Board_SelectAll

    public List<Board> PR_Board_SelectAll()
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Board_SelectAll");
            // _sqlDatabase.AddInParameter(cmd, "SanskarID", SqlDbType.Int, 1);
            List<Board> _boards = new List<Board>();
            using (IDataReader idr = _sqlDatabase.ExecuteReader(cmd))
            {
                while (idr.Read())
                {
                    Board _bd = new Board();
                    _bd.BoardId = Convert.ToInt32(idr["BoardID"]);
                    // _bd.ClassesId = Convert.ToInt32(idr["ClassesId"]);
                    _bd.BoardName = idr["BoardName"].ToString();

                    // 
                    _bd.CreatedAt = idr["CreatedAt"] != DBNull.Value
                        ? Convert.ToDateTime(idr["CreatedAt"])
                        : (DateTime?)null;
                    _bd.ModifiedAt = idr["ModifiedAt"] != DBNull.Value
                        ? Convert.ToDateTime(idr["ModifiedAt"])
                        : (DateTime?)null;

                    _boards.Add(_bd);
                }
            }

            return _boards;
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    #endregion

    #region Method : PR_Board_SelectByPK

    public Board PR_Board_SelectByPK(int boardId)
    {
        try
        {
            DbCommand cmd = _sqlDatabase.GetStoredProcCommand("PR_Board_SelectByPK");
            _sqlDatabase.AddInParameter(cmd, "BoardId", SqlDbType.Int, boardId);
            // _sqlDatabase.AddInParameter(cmd, "SanskarID", SqlDbType.Int, 1);
            Board board = null;
            using (IDataReader idr = _sqlDatabase.ExecuteReader(cmd))
            {
                if (idr.Read())
                {
                    board = new Board
                    {
                        BoardId = Convert.ToInt32(idr["BoardId"]),
                        // ClassesId = Convert.ToInt32(idr["ClassesId"]),
                        BoardName = idr["BoardName"].ToString(),
                        CreatedAt = idr["CreatedAt"] != DBNull.Value
                            ? Convert.ToDateTime(idr["CreatedAt"])
                            : (DateTime?)null,
                        ModifiedAt = idr["ModifiedAt"] != DBNull.Value
                            ? Convert.ToDateTime(idr["ModifiedAt"])
                            : (DateTime?)null
                    };
                }
            }

            return board;
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    #endregion
}