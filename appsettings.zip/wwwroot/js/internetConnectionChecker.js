﻿const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: true,
    onOpen: (toast) => {
        toast.addEventListener('mouseenter', Swal.stopTimer);
        toast.addEventListener('mouseleave', Swal.resumeTimer);
    }
});

window.addEventListener('offline', function () {
    showToast('error', '<i class="bi bi-wifi-off"></i> No internet connection');
    console.log("User Is Offline");
});

window.addEventListener('online', function () {
    showToast('success', '<i class="bi bi-wifi"></i> Internet connection restored');
    console.log("User Is Online");
});

function showToast(icon, title) {
    Toast.fire({
        icon: icon,
        title: title
    });
}
