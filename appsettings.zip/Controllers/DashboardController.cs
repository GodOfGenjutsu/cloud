﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Sanskar_Admin.BAL;
using Sanskar_Admin.Models;

namespace Sanskar_Admin.Controllers;

[CustomAuthorize("Admin", "Staff", "Student")]
public class DashboardController : Controller
{
    #region Configuration

    private readonly ILogger<DashboardController> _logger;
    private readonly DashBoardBAL _dashBoardBal;

    public DashboardController(ILogger<DashboardController> logger, DashBoardBAL dashBoardBAL)
    {
        _logger = logger;
        _dashBoardBal = dashBoardBAL;
    }

    #endregion

    #region Dashboard

    [CustomAuthorize("Admin", "Staff", "Student")]
    public IActionResult Index()
    {
        Console.WriteLine($"Request is came into the dashboard controller");
        try
        {
            if (Convert.ToBoolean(TempData["LoginAlert"]))
            {
                TempData["LoginAlert"] = false;
                TempData["ShowSuccessAlert"] = true;
                TempData["SuccessMessage"] = "Login Successfully";
            }

            Console.WriteLine($"Dashboard Controller: {_dashBoardBal.PR_DashBoard_Conunt()}");
            
            string userRole = CV.Role();
            
            if (userRole.Equals("Student"))
            {
                StudentBal _studentBal = new StudentBal();
                var userId = HttpContext.Session.GetInt32("UserID");
                var student = _studentBal.PR_Student_SelectById(userId.Value);
                return View("StudentDashboard", student);
            }
            else if (userRole.Equals("Staff"))
            {
                StaffBAL _staffBal = new StaffBAL();
                var userId = HttpContext.Session.GetInt32("UserID");
                var staff = _staffBal.PR_Staff_SelectById(userId.Value);
                return View("StaffDashboard", staff);
            }

            return View(_dashBoardBal.PR_DashBoard_Conunt());
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    #endregion
}