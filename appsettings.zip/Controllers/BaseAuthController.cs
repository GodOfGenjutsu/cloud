﻿// Controllers/BaseAuthController.cs
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace Sanskar_Admin.Controllers;

public class BaseAuthController : Controller
{
    protected string? UserRole => HttpContext.Session.GetString("UserRole");
    protected int? UserID => HttpContext.Session.GetInt32("UserID");
    protected string? UserName => HttpContext.Session.GetString("UserName");

    public override void OnActionExecuting(ActionExecutingContext context)
    {
        // Check if the user is not authenticated AND the action doesn't have [AllowAnonymous]
        if (string.IsNullOrEmpty(UserRole) && !context.ActionDescriptor.EndpointMetadata.Any(em => em is Microsoft.AspNetCore.Authorization.AllowAnonymousAttribute))
        {
            // Check if the current action is already the login action to avoid redirect loop
            var controllerName = context.RouteData.Values["controller"]?.ToString();
            var actionName = context.RouteData.Values["action"]?.ToString();

            if (controllerName != "Auth" || actionName != "Login")
            {
                // User is not authenticated, redirect to login
                context.Result = RedirectToAction("Login", "Auth", new { area = "Auth" });
            }
        }
        base.OnActionExecuting(context);
    }
}