﻿using Microsoft.AspNetCore.Mvc;

namespace Sanskar_Admin.Controllers;

public class WildCardController : Controller
{
    #region 404 Error

    public IActionResult Error404()
    {
        return View();
    }

    #endregion

    public IActionResult ServerError()
    {
        return View();
    }
}