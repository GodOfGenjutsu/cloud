﻿// Controllers/AdminController.cs admin pass : Tnb2pn012
using Microsoft.AspNetCore.Mvc;
using Sanskar_Admin.BAL;
using Sanskar_Admin.Models;
using Microsoft.AspNetCore.Hosting; // Add this
using System.IO;
using System;
using System.Threading.Tasks;

namespace Sanskar_Admin.Controllers;

public class AdminController : Controller
{
    #region Configuration

    private readonly AdminProfileBAL _adminProfileBal;
    private readonly IWebHostEnvironment _webHostEnvironment; // Add this

    public AdminController(AdminProfileBAL adminProfileBal, IWebHostEnvironment webHostEnvironment) // Update constructor
    {
        _adminProfileBal = adminProfileBal;
        _webHostEnvironment = webHostEnvironment;
    }

    #endregion

    [CustomAuthorize("Admin", "Staff")]
    public IActionResult Index()
    {
        return View();
    }

    [CustomAuthorize("Admin", "Staff")]
    public IActionResult ProfileEdit()
    {
        AdminProfileViewModel obj = _adminProfileBal.AdminProfile_SelectByID();
        obj.NewPassword = "";
        return View(obj);
    }

    [HttpPost]
    [CustomAuthorize("Admin", "Staff")]
    public async Task<IActionResult> ProfileEdit(AdminProfileViewModel model)
    {
        if (ModelState.IsValid)
        {
            // Handle image upload
            if (model.ProfileImage != null)
            {
                string uploadsFolder = Path.Combine(_webHostEnvironment.WebRootPath, "uploads/profile");

                // Create the directory if it doesn't exist
                if (!Directory.Exists(uploadsFolder))
                {
                    Directory.CreateDirectory(uploadsFolder);
                }

                string uniqueFileName = Guid.NewGuid().ToString() + "_" + model.ProfileImage.FileName;
                string filePath = Path.Combine(uploadsFolder, uniqueFileName);

                // Save the file to the server
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    await model.ProfileImage.CopyToAsync(fileStream);
                }

                // Delete the old image if it exists
                if (!string.IsNullOrEmpty(model.ExistingProfileImage))
                {
                    string oldFilePath = Path.Combine(_webHostEnvironment.WebRootPath, "uploads/profile", model.ExistingProfileImage);
                    if (System.IO.File.Exists(oldFilePath))
                    {
                        System.IO.File.Delete(oldFilePath);
                    }
                }

                // Update the model with the new file name
                model.ExistingProfileImage = uniqueFileName;
            }

            // Update the admin profile
            bool updateResult = _adminProfileBal.UpdateAdminProfile(model);

            if (updateResult)
            {
                 HttpContext.Session.SetString("ProfileImagePath", model.ExistingProfileImage);
                return Json(new { success = true, message = "Profile updated successfully!" });
            }
            else
            {
                return Json(new { success = false, message = "Failed to update profile." });
            }
        }

        return View(model);
    }
}