﻿using Microsoft.AspNetCore.Mvc;
using NuGet.Protocol;
using Sanskar_Admin.BAL;

namespace Sanskar_Admin.Controllers;

[CustomAuthorize("Admin", "Staff")]
public class DropDownController : Controller
{
    #region Configuration

    private readonly StudentBal _studentBal;

    public DropDownController(StudentBal studentBal)
    {
        _studentBal = studentBal;
    }

    #endregion

    #region Get Boards

    public IActionResult GetBoards()
    {
        return Json(_studentBal.PR_Board_DropDownList().ToJson());
    }

    #endregion

    #region Get Standards

    public IActionResult GetStandards()
    {
        return Json(_studentBal.PR_Standard_DropDownList().ToJson());
    }

    #endregion

    #region Get Divisions

    public IActionResult GetDivisions()

    {
        return Json(_studentBal.PR_Division_DropDownList().ToJson());
    }

    #endregion

    #region Get Mediums

    public IActionResult GetMediums()
    {
        return Json(_studentBal.PR_Medium_DropDownList().ToJson());
    }

    #endregion

    #region Get AcademicYears

    public IActionResult GetAcademicYears()
    {
        return Json(_studentBal.PR_AcademicYear_DropDown().ToJson());
    }

    #endregion
}