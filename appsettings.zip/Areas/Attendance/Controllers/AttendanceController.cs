﻿using Microsoft.AspNetCore.Mvc;
using Sanskar_Admin.BAL;
using Sanskar_Admin.Models;
namespace Sanskar_Admin.Areas.Attendance.Controllers;

[CustomAuthorize("Admin", "Staff", "Student")]
[Area("Attendance")]
public class AttendanceController : Controller
{
    private readonly AttendanceBAL _attendanceBal;
    private readonly StudentBal _studentBal;

    public AttendanceController(AttendanceBAL attendanceBal, StudentBal studentBal)
    {
        _attendanceBal = attendanceBal;
        _studentBal = studentBal;
    }

    #region Attendance Calendar View
    [CustomAuthorize("Admin", "Staff", "Student")]
    public IActionResult Calendar(int? year = null, int? month = null)
    {
        var userRole = HttpContext.Session.GetString("UserRole");
        var userId = HttpContext.Session.GetInt32("UserID");

        if (year == null)
            year = DateTime.Now.Year;
        if (month == null)
            month = DateTime.Now.Month;

        ViewBag.Year = year.Value;
        ViewBag.Month = month.Value;
        ViewBag.UserRole = userRole;

        if (userRole == "Student" && userId.HasValue)
        {
            // For students, we'll return their own attendance data
            var startDate = new DateTime(year.Value, month.Value, 1);
            var endDate = startDate.AddMonths(1).AddDays(-1);

            var attendanceData = _attendanceBal.PR_Attendance_SelectByStudentId(userId.Value, startDate, endDate);
            return View("StudentCalendar", attendanceData);
        }

        // For Admin and Staff, just show the calendar
        return View();
    }
    #endregion

    #region View Attendance for Date
    [HttpGet]
    [CustomAuthorize("Admin", "Staff")]
    public IActionResult ViewAttendance(DateTime date, int? standardId = null, int? divisionId = null)
    {
        ViewBag.Date = date;
        ViewBag.StandardList = _studentBal.PR_Standard_DropDownList();
        ViewBag.DivisionList = _studentBal.PR_Division_DropDownList();

        ViewBag.SelectedStandardId = standardId;
        ViewBag.SelectedDivisionId = divisionId;

        if (standardId.HasValue && divisionId.HasValue)
        {
            var attendanceList = _attendanceBal.PR_Attendance_SelectByDate(date, standardId.Value, divisionId.Value);
            return View(attendanceList);
        }

        return View(new List<Models.Attendance>());
    }
    #endregion

    #region Mark Attendance
    [HttpPost]
    [CustomAuthorize("Admin", "Staff")]
    public IActionResult MarkAttendance(List<Models.Attendance> attendances)
    {
        try
        {
            if (attendances == null || attendances.Count == 0)
            {
                return Json(new { success = false, message = "No attendance data received." });
            }

            // Log the received data
            Console.WriteLine($"Received {attendances.Count} attendance records.");
            foreach (var attendance in attendances.Take(3)) // Log first few for debugging
            {
                Console.WriteLine($"Record: ID={attendance.AttendanceId}, Student={attendance.StudentId}, Present={attendance.IsPresent}");
            }

            var existingAttendances = attendances.Where(a => a.AttendanceId > 0).ToList();
            var newAttendances = attendances.Where(a => a.AttendanceId == 0).ToList();

            Console.WriteLine($"Found {existingAttendances.Count} existing and {newAttendances.Count} new records.");

            bool success = true;

            if (existingAttendances.Any())
            {
                success = _attendanceBal.PR_Attendance_Update(existingAttendances);
                Console.WriteLine($"Update result: {success}");
            }

            if (newAttendances.Any())
            {
                var insertResult = _attendanceBal.PR_Attendance_Insert(newAttendances);
                Console.WriteLine($"Insert result: {insertResult}");
                success = success && insertResult;
            }

            if (success)
            {
                return Json(new { success = true, message = "Attendance marked successfully." });
            }
            else
            {
                return Json(new { success = false, message = "Failed to mark attendance." });
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error in MarkAttendance: {ex.Message}");
            Console.WriteLine(ex.StackTrace);
            return Json(new { success = false, message = ex.Message });
        }
    }
    #endregion

    #region Student View Attendance
    [CustomAuthorize("Student")]
    public IActionResult ViewAttendance()
    {
        var userId = HttpContext.Session.GetInt32("UserId");
        if (userId.HasValue)
        {
            var today = DateTime.Today;
            var startDate = new DateTime(today.Year, today.Month, 1);
            var endDate = startDate.AddMonths(1).AddDays(-1);

            var attendanceData = _attendanceBal.PR_Attendance_SelectByStudentId(userId.Value, startDate, endDate);
            return View("StudentCalendar", attendanceData);
        }

        return RedirectToAction("Index", "Dashboard");
    }
    #endregion
}