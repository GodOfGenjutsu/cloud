﻿using Microsoft.AspNetCore.Mvc;
using Sanskar_Admin.BAL;

namespace Sanskar_Admin.Areas.AcademicYear.Controllers;

[Area("AcademicYear")]
[CustomAuthorize("Admin", "Staff")]
public class AcademicYearController : Controller
{
    #region Configuration

    private readonly AcademicYearBAL _academicYearBal;

    public AcademicYearController()
    {
        _academicYearBal = new AcademicYearBAL();
    }

    #endregion

    #region Select All

    public IActionResult Index()
    {
        return View(_academicYearBal.PR_AcademicYear_SelectAll());
    }

    #endregion

    #region Add_Edit

    public IActionResult Add_Edit(int acadecYearId = 0)
    {
        if (acadecYearId != 0)
        {
            return View(_academicYearBal.PR_AcademicYear_SelectById(acadecYearId));
        }

        return View();
    }

    #endregion

    #region Save

    [HttpPost]
    public IActionResult Save(Models.AcademicYear obj)
    {

        if (obj.AcademicYearId == 0)
        {
            _academicYearBal.PR_AcademicYear_Insert(obj);
            return Json(new { success = true, message = "Inserted completed successfully." });
        }
        else
        {
            _academicYearBal.PR_AcademicYear_Update(obj);
            return Json(new { success = true, message = "Updated completed successfully." });
        }
    }

    #endregion

    #region Delete

    public IActionResult Delete(int academicYearId)
    {
        bool isDeleted = _academicYearBal.PR_AcademicYear_Delete(academicYearId);
        if (isDeleted)
        {
            return Ok();
        }

        return NotFound();
    }

    #endregion
}