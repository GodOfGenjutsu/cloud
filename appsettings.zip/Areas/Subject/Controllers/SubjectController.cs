using Microsoft.AspNetCore.Mvc;
using Sanskar_Admin.BAL;

namespace Sanskar_Admin.Areas.Subject.Controllers;

[Area("Subject")]
[CustomAuthorize("Admin", "Staff")]
public class SubjectController : Controller
{
    #region Configuration

    private readonly SubjectBAL _subjectBal;

    public SubjectController()
    {
        _subjectBal = new SubjectBAL();
    }

    #endregion

    #region All Subjects

    public IActionResult Index()
    {
        var subject = _subjectBal.PR_Subject_SelectAll();
        return View("Index", subject);
    }

    #endregion

    #region Add/Edit

    public IActionResult Add_Edit(int SubjectId)
    {
        if (SubjectId != 0)
        {
            return View("Add_Edit", _subjectBal.PR_Subject_SelectById(SubjectId));
        }

        return View("Add_Edit", new Models.Subject());
    }

    #endregion

    #region Save

    [HttpPost]
    public IActionResult Save(Models.Subject obj)
    {
        if (obj.SubjectId == 0)
        {
            return _subjectBal.PR_Subject_Insert(obj)
                ? Json(new { success = true, message = "Inserted completed successfully." })
                : Json(new { success = false, message = "An error occurred while processing your request." });
        }
        else
        {
            return _subjectBal.PR_Subject_Update(obj)
                ? Json(new { success = true, message = "Updated completed successfully." })
                : Json(new { success = false, message = "An error occurred while processing your request." });
        }
    }

    #endregion

    #region Delete

    public IActionResult Delete(int SubjectId)
    {
        // _subjectBal.PR_Subject_Delete(SubjectId);
        // return RedirectToAction("Index");
        if (_subjectBal.PR_Subject_Delete(SubjectId))
        {
            return Ok();
        }
        else
        {
            return BadRequest();
        }
    }

    #endregion
}