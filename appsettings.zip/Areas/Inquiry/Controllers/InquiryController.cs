﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Sanskar_Admin.BAL;
using Sanskar_Admin.Models;

namespace Sanskar_Admin.Areas.Inquiry.Controllers;

[Area("Inquiry")]
public class InquiryController : Controller
{
    #region Configuration

    private readonly InquiryBAL _inquiryBal;

    public InquiryController(InquiryBAL inquiryBal)
    {
        _inquiryBal = inquiryBal;
    }

    #endregion

    #region All Inquirys

    [CustomAuthorize("Admin", "Staff")]
    public IActionResult Index()
    {
        var inquiry = _inquiryBal.PR_Inquiry_SelectAll();
        return View(inquiry);
    }

    #endregion

    #region Inquiry Form

    [AllowAnonymous]
    public IActionResult Add()
    {
        ViewBag.BoardList = _inquiryBal.GetBoardsDLL();
        ViewBag.MediumList = _inquiryBal.GetMediumsDLL();
        ViewBag.StandardList = _inquiryBal.GetStandardDLL();
        // ViewBag.SanskarList = _inquiryBal.GetSanskarDLL();
        return View();
    }

    #endregion

    #region Inquiry Details

    [CustomAuthorize("Admin", "Staff")]
    public IActionResult Details(int InquiryId)
    {
        var inquiry = _inquiryBal.PR_Inquiry_SelectByPK(InquiryId);
        if (inquiry == null)
        {
            return NotFound(); // Return 404 if inquiry with given ID is not found
        }

        return View(inquiry);
    }

    #endregion

    #region Save Inquiry Request

    [HttpPost]
    [AllowAnonymous]
    [ValidateAntiForgeryToken]
    public IActionResult Save(Models.Inquiry model)
    {
        return _inquiryBal.PR_Inquiry_Insert(model) ? Json(new { status = 200 }) : Json(new { status = 404 });
    }

    #endregion

    #region Delete

    [CustomAuthorize("Admin", "Staff")]
    [HttpPost]
    public IActionResult Delete(int InquiryId)
    {
        try
        {
            bool deleteSuccess = _inquiryBal.PR_Inquiry_Delete(InquiryId);

            if (deleteSuccess)
            {
                return Ok();
            }
            else
            {
                return NotFound();
            }
        }
        catch (Exception ex)
        {
            TempData["ShowErrorAlert"] = true;
            TempData["ErrorMessage"] = $"Exception during deletion: {ex.Message}";

            // Optionally, you can rethrow the exception for further analysis
            throw;
        }
    }

    #endregion

    #region Filter

    public IActionResult Search(string name, DateTime? date)
    {
        var Inquiries = _inquiryBal.PR_Inquiry_SelectAll();

        var filteredInquiries = Inquiries
            .Where(i => (name == null || i.StudentFirstName.Contains(name) || i.StudentLastName.Contains(name) ||
                         i.StudentMiddleName.Contains(name))
                        && (date == null || i.CreatedAt.Date == date.Value.Date))
            .ToList();

        return View("Index", filteredInquiries);
    }

    #endregion
}