﻿using Microsoft.AspNetCore.Mvc;
using Sanskar_Admin.BAL;

namespace Sanskar_Admin.Areas.YearWiseFee.Controllers;

[Area("YearWiseFee")]
[CustomAuthorize("Admin", "Staff")]

public class YearWiseFeeController : Controller
{
    #region Configuration

    private readonly YearWiseFeeBAL _yearWiseFeeBal;

    public YearWiseFeeController()
    {
        _yearWiseFeeBal = new YearWiseFeeBAL();
    }

    #endregion

    #region Select All

    public IActionResult Index()
    {
        return View(_yearWiseFeeBal.PR_YearWiseFee_SelectAll());
    }

    #endregion

    #region Add_Edit

    public IActionResult Add_Edit(int yearWiseFeeId = 0)
    {
        if (yearWiseFeeId != 0)
        {
            return View(_yearWiseFeeBal.PR_YearWiseFee_SelectById(yearWiseFeeId));
        }

        return View();
    }

    #endregion

    #region Save

    public IActionResult Save(Models.YearWiseFee obj)
    {
        if (obj.YearWiseFeeId == 0)
        {
            return _yearWiseFeeBal.PR_YearWiseFee_Insert(obj)?Json(new { success = true, message = "Inserted completed successfully." }):Json(new { success = false, message = "An error occurred while processing your request." });
            // return true
                // ? Json(new { success = true, message = "Inserted completed successfully." })
                // : Json(new { success = false, message = "An error occurred while processing your request." });
        }
        else
        {
            return _yearWiseFeeBal.PR_YearWiseFee_Update(obj) ? Json(new { success = true, message = "Updated completed successfully." }) :Json(new { success = false, message = "An error occurred while processing your request." });;
            // return true
                // ? Json(new { success = true, message = "Updated completed successfully." })
                // : Json(new { success = false, message = "An error occurred while processing your request." });
        }
    }

    #endregion

    #region Delete

    public IActionResult Delete(int yearWiseFeeId)
    {
        if (_yearWiseFeeBal.PR_YearWiseFee_Delete(yearWiseFeeId))
        {
            return Ok();
        }

        return NotFound();
    }

    #endregion
}