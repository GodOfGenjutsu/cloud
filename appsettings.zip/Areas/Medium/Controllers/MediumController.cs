﻿using Microsoft.AspNetCore.Mvc;
using Sanskar_Admin.BAL;

namespace Sanskar_Admin.Areas.Medium.Controllers;

[Area("Medium")]
[CustomAuthorize("Admin", "Staff")]
public class MediumController : Controller
{
    #region Configuration

    private readonly MediumBAL _mediumBal;

    public MediumController()
    {
        _mediumBal = new MediumBAL();
    }

    #endregion

    #region All Mediums

    public IActionResult Index()
    {
        var mediums = _mediumBal.PR_Medium_SelectAll();
        return View("Index", mediums);
    }

    #endregion

    #region Add/Edit

    public IActionResult Add_Edit(int mediumId)
    {
        if (mediumId != 0)
        {
            return View("Add_Edit", _mediumBal.PR_Medium_SelectByPK(mediumId));
        }
        else
        {
            return View("Add_Edit", new Models.Medium());
        }
    }

    #endregion

    #region Save

    [HttpPost]
    public IActionResult Save(Models.Medium obj)
    {
        if (obj.MediumId == 0)
        {
            return _mediumBal.PR_Medium_Insert(obj)
                ? Json(new { success = true, message = "Inserted completed successfully." })
                : Json(new { success = false, message = "An error occurred while processing your request." });
        }
        else
        {
            return _mediumBal.PR_Medium_Update(obj)
                ? Json(new { success = true, message = "Updated completed successfully." })
                : Json(new { success = false, message = "An error occurred while processing your request." });
        }
    }

    #endregion

    #region Delete

    public IActionResult Delete(int MediumId)
    {
        if (_mediumBal.PR_Medium_Delete(MediumId))
        {
            return Ok();
        }
        else
        {
            return BadRequest();
        }
    }

    #endregion
}