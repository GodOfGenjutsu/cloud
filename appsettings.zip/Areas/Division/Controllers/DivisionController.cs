using Microsoft.AspNetCore.Mvc;
using Sanskar_Admin.BAL;

namespace Sanskar_Admin.Areas.Division.Controllers;

[Area("Division")]
[CustomAuthorize("Admin", "Staff")]
public class DivisionController : Controller
{
    #region Configuration

    private readonly DivisionBAL _divisionBal;

    public DivisionController()
    {
        _divisionBal = new DivisionBAL();
    }

    #endregion

    #region All Divisions

    public IActionResult Index()
    {
        var divisions = _divisionBal.PR_Division_SelectAll();
        return View("Index", divisions);
    }

    #endregion

    #region Add/Edit

    public IActionResult Add_Edit(int DivisionId)
    {
        if (DivisionId != 0)
        {
            ViewBag.pr_standard_dropDown = _divisionBal.PR_Standard_DropDown();
            return View("Add_Edit", _divisionBal.PR_Division_SelectByPK(DivisionId));
        }
        else
        {
            ViewBag.pr_standard_dropDown = _divisionBal.PR_Standard_DropDown();
            return View("Add_Edit");
        }
    }

    #endregion

    #region Save

    [HttpPost]
    public IActionResult Save(Models.Division obj)
    {
        if (obj.DivisionId == 0)
        {
            return _divisionBal.PR_Division_Insert(obj)
                ? Json(new { success = true, message = "Inserted completed successfully." })
                : Json(new { success = false, message = "An error occurred while processing your request." });
        }
        else
        {
            return _divisionBal.PR_Division_Update(obj)
                ? Json(new { success = true, message = "Updated completed successfully." })
                : Json(new { success = false, message = "An error occurred while processing your request." });
        }
    }

    #endregion

    #region Delete

    public IActionResult Delete(int DivisionId)
    {
        if (_divisionBal.PR_Division_Delete(DivisionId))
        {
            return Ok();
        }
        else
        {
            return BadRequest();
        }
    }

    #endregion
}