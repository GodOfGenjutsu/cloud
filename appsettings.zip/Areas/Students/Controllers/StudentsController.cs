﻿using Microsoft.AspNetCore.Mvc;
using Sanskar_Admin.BAL;
using Sanskar_Admin.Models;

namespace Sanskar_Admin.Areas.Students.Controllers;

[Area("Students")]
[CustomAuthorize("Admin", "Staff")]
public class StudentsController : Controller
{
    #region Configuration

    private readonly StudentBal _studentBal;
    private InquiryBAL _inquiryBal;

    public StudentsController(StudentBal studentBal)
    {
        _studentBal = studentBal;
    }

    #endregion

    #region All Students

    public IActionResult Index()
    {
        var data = _studentBal.PR_Student_SelectAll();
        return View(data);
    }

    #endregion

    #region Student Details

    public IActionResult Details(int id)
    {
        return View(_studentBal.PR_Student_SelectById(id));
    }

    #endregion

    #region Approve Inquiry

    public IActionResult ApproveInquiry(Sanskar_Admin.Models.Inquiry model)
    {
        TempData["IsInquiryApproved"] = model.InquiryId;
        Student obj = new Student();
        obj = Student.ConvertToStudent(model);
        return View("Add_Edit", obj);
    }

    #endregion

    #region Add/Edit

    public IActionResult Add_Edit(int studentId)
    {
        if (studentId != 0)
        {
            var obj = _studentBal.PR_Student_SelectById(studentId);
            return View(obj);
        }

        return View();
    }

    #endregion

    #region Save

    public IActionResult Save(Student model)
    {
        /*if (!ModelState.IsValid)
        {
            return RedirectToAction("Add_Edit");
        }*/

        // model.ClassesId = CV.SanskarID();
        if (model.StudentId == 0)
        {
            if (TempData["IsInquiryApproved"] != null)
            {
                _inquiryBal = new InquiryBAL();
                _inquiryBal.PR_Inquiry_Delete(Convert.ToInt32(TempData["IsInquiryApproved"]));
            }

            return _studentBal.PR_Student_Insert(model)
                ? Json(new { success = true, message = "Inserted completed successfully." })
                : Json(new { success = false, message = "An error occurred while processing your request." });
            // return true?Json(new { success = true, message = "Inserted completed successfully." }):Json(new { success = false, message = "An error occurred while processing your request." });
        }
        else
        {
            return _studentBal.PR_Student_Update(model)
                ? Json(new { success = true, message = "Updated completed successfully." })
                : Json(new { success = false, message = "An error occurred while processing your request." });
            ;
            // return true ? Json(new { success = true, message = "Updated completed successfully." }) :Json(new { success = false, message = "An error occurred while processing your request." });;
        }
        /*if (model.StudentId == 0)
        {
            TempData["ShowSuccessAlert"] = _studentBal.PR_Student_Insert(model);
            TempData["SuccessMessage"] = "Added Successfully";
        }
        else
        {
            TempData["ShowSuccessAlert"] = _studentBal.PR_Student_Update(model);
            TempData["SuccessMessage"] = "Updated Successfully";
        }*/
    }

    #endregion

    #region Delete

    [HttpDelete]
    public IActionResult Delete(int studentId)
    {
        bool isDeleted = _studentBal.PR_Student_Delete(studentId);
        // bool isDeleted = true;
        if (isDeleted)
        {
            // If deletion is successful, return a success status
            return Ok();
        }
        else
        {
            // If deletion fails, return a bad request status
            return BadRequest();
        }

        // return RedirectToAction("Index");
    }

    #endregion
}