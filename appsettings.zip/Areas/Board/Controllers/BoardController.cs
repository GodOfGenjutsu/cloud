﻿using Microsoft.AspNetCore.Mvc;
using Sanskar_Admin.BAL;
using Sanskar_Admin.Models;

namespace Sanskar_Admin.Areas.Board.Controllers;

[Area("Board")]
[CustomAuthorize("Admin", "Staff")]
public class BoardController : Controller
{
    #region Configuration

    private readonly BoardBAL _boardBal;

    public BoardController()
    {
        _boardBal = new BoardBAL();
    }

    #endregion

    #region All Boards

    public IActionResult Index()
    {
        var boards = _boardBal.PR_Board_SelectAll();
        return View(boards);
    }

    #endregion

    #region Board Add/Edit

    public IActionResult Add_Edit(int boardId)
    {
        if (boardId != 0)
        {
            return View("Add_Edit", _boardBal.PR_Board_SelectByPK(boardId));
        }
        else
        {
            return View("Add_Edit", new Models.Board());
        }
    }

    #endregion

    #region Save

    [HttpPost]
    public IActionResult Save(Models.Board obj)
    {
        if (obj.BoardId == 0)
        {
            return _boardBal.PR_Board_Insert(obj)
                ? Json(new { success = true, message = "Inserted completed successfully." })
                : Json(new { success = false, message = "An error occurred while processing your request." });
        }
        else
        {
            return _boardBal.PR_Board_Update(obj)
                ? Json(new { success = true, message = "Updated completed successfully." })
                : Json(new { success = false, message = "An error occurred while processing your request." });
        }
    }

    #endregion

    #region Delete

    public IActionResult Delete(int boardId)
    {
        // return Ok();
        if (_boardBal.PR_Board_Delete(boardId))
        {
            return Ok();
        }
        else
        {
            return BadRequest();
        }
    }

    #endregion
}