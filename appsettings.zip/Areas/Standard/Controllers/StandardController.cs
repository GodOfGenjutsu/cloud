﻿using Microsoft.AspNetCore.Mvc;
using Sanskar_Admin.BAL;

namespace Sanskar_Admin.Areas.Standard.Controllers;

[Area("Standard")]
[CustomAuthorize("Admin", "Staff")]
public class StandardController : Controller
{
    #region Configuration

    private readonly StandardBAL _standardBAL;

    public StandardController()
    {
        _standardBAL = new StandardBAL();
    }

    #endregion

    #region All Standards

    public IActionResult Index()
    {
        var standards = _standardBAL.PR_Standard_SelectAll();
        return View("Index", standards);
    }

    #endregion

    #region Add/Edit

    public IActionResult Add_Edit(int StandardId)
    {
        if (StandardId != 0)
        {
            return View("Add_Edit", _standardBAL.PR_Standard_SelectByPK(StandardId));
        }
        else
        {
            return View("Add_Edit", new Models.Standard());
        }
    }

    #endregion

    #region Save

    [HttpPost]
    public IActionResult Save(Models.Standard obj)
    {
        if (obj.StandardId == 0)
        {
            return _standardBAL.PR_Standard_Insert(obj)
                ? Json(new { success = true, message = "Inserted completed successfully." })
                : Json(new { success = false, message = "An error occurred while processing your request." });
        }
        else
        {
            return _standardBAL.PR_Standard_Update(obj)
                ? Json(new { success = true, message = "Updated completed successfully." })
                : Json(new { success = false, message = "An error occurred while processing your request." });
        }
    }

    #endregion

    #region Delete

    public IActionResult Delete(int StandardId)
    {
        // _standardBAL.PR_Standard_Delete(StandardId);
        // return RedirectToAction("Index");
        if (_standardBAL.PR_Standard_Delete(StandardId))
        {
            return Ok();
        }
        else
        {
            return BadRequest();
        }
    }

    #endregion
}