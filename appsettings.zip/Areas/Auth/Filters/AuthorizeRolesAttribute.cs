﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace Sanskar_Admin.Areas.Auth.Filters;

public class AuthorizeRolesAttribute : TypeFilterAttribute
{
    public AuthorizeRolesAttribute(params string[] roles) : base(typeof(RoleFilter))
    {
        Arguments = new object[] { roles };
    }
}

public class RoleFilter : IAuthorizationFilter
{
    private readonly string[] _roles;

    public RoleFilter(string[] roles)
    {
        _roles = roles;
    }

    public void OnAuthorization(AuthorizationFilterContext context)
    {
        var role = context.HttpContext.Session.GetString("UserRole");
        
        if (!_roles.Contains(role))
        {
            context.Result = new RedirectToActionResult("Login", "Auth", new { area = "Auth" });
        }
    }
}