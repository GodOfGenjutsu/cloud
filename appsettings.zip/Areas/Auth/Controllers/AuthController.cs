﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Sanskar_Admin.Areas.Auth.Models;
using Sanskar_Admin.BAL;
using Sanskar_Admin.Controllers;

namespace Sanskar_Admin.Areas.Auth.Controllers;
// Areas/Auth/Controllers/AuthController.cs

[Area("Auth")]
public class AuthController : BaseAuthController
{
    private readonly LoginBAL _loginBal;

    public AuthController(LoginBAL loginBal)
    {
        _loginBal = loginBal;
    }

    // Login Page
    [AllowAnonymous]
    public IActionResult Login(Login? model)
    {
        if (TempData["ShowInquiryAlert"] != null && (bool)TempData["ShowInquiryAlert"] == true)
        {
            TempData["InquiryAlert"] = true;
            TempData["SuccessMessage"] = "Inquiry Added Successfully";
        }

        if (UserRole != null)
        {
            return RedirectToDashboard();
        }

        return View();
    }

    // Login User Method
    [HttpPost]
    [AllowAnonymous]
    [ValidateAntiForgeryToken]
    public IActionResult LoginUser(Login model)
    {
        if (ModelState.IsValid)
        {
            // Admin Login
            var admin = _loginBal.PR_Admin_Login(model);
            if (admin != null && admin.AdminId > 0)
            {
                TempData["ShowSuccessAlert"] = true;
                SetupSession("Admin", admin.AdminId, admin.AdminName, model.Email,admin.ProfileImage);
                return RedirectToAction("Index", "Dashboard", new { area = "" });
            }

            // Staff Login
            var staff = _loginBal.PR_Staff_Login(model);
            if (staff != null && staff.StaffID > 0)
            {
                SetupSession("Staff", staff.StaffID, staff.StaffName, model.Email,"");
                return RedirectToAction("Index", "Dashboard", new { area = "" });
            }

            // Student Login
            var student = _loginBal.PR_Student_Login(model);
            if (student != null && student.StudentId > 0)
            {
                SetupSession("Student", student.StudentId, student.StudentFirstName, model.Email,"");
                return RedirectToAction("Index", "Dashboard", new { area = "" });
            }

            // Invalid Login
            TempData["ShowErrorAlert"] = true;
            TempData["ErrorMessage"] = "Invalid Email or Password";
            return View("Login", model);
        }

        // Model State is Invalid
        return View("Login", model);
    }

    // Sign Out Method
    public IActionResult SignOutUser()
    {
        HttpContext.Session.Clear();
        return RedirectToAction("Login");
    }

    private void SetupSession(string role, int userId, string userName, string email,string? profileImage)
    {
        HttpContext.Session.SetString("UserRole", role);
        HttpContext.Session.SetInt32("UserID", userId);
        HttpContext.Session.SetString("UserName", userName);
        HttpContext.Session.SetString("Email", email);
        HttpContext.Session.SetString("ProfileImage",profileImage);
    }

    private IActionResult RedirectToDashboard()
    {
        if (UserRole == "Admin")
        {
            return RedirectToAction("Index", "Dashboard", new { area = "" });
        }
        else if (UserRole == "Staff")
        {
            // Redirect to the main Dashboard controller which will now show StaffDashboard view
            return RedirectToAction("Index", "Dashboard", new { area = "" });
        }
        else if (UserRole == "Student")
        {
            return RedirectToAction("Index", "Dashboard", new { area = "" });
        }
        else
        {
            return RedirectToAction("Login", "Auth");
        }
    }
}


