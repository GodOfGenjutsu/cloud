﻿using Microsoft.AspNetCore.Mvc;
using Sanskar_Admin.BAL;

namespace Sanskar_Admin.Areas.Staff.Controllers;

[Area("Staff")]
[CustomAuthorize("Admin", "Staff")]
public class StaffController : Controller
{
    #region Configuration

    private readonly StaffBAL _staffBal;

    public StaffController()
    {
        _staffBal = new StaffBAL();
    }

    #endregion

    #region All Staffs

    public IActionResult Index()
    {
        var Staff = _staffBal.PR_Staff_SelectAll();
        return View("Index", Staff);
    }

    #endregion

    #region Add/Edit

    public IActionResult Add_Edit(int StaffId)
    {
        if (StaffId != 0)
        {
            return View("Add_Edit", _staffBal.PR_Staff_SelectById(StaffId));
        }
        else
        {
            return View("Add_Edit");
        }
    }

    #endregion

    #region Save

    [HttpPost]
    public IActionResult Save(Models.Staff obj)
    {
        if (obj.StaffID == 0)
        {
            if (_staffBal.PR_Staff_Insert(obj))
            {
                return Json(new { success = true, message = "Inserted completed successfully." });
            }
            else
            {
                return Json(new { success = false, message = "An error occurred while processing your request." });
            }
        }
        else
        {
            if (_staffBal.PR_Staff_Update(obj))
            {
                return Json(new { success = true, message = "Updated completed successfully." });
            }
            else
            {
                return Json(new { success = false, message = "An error occurred while processing your request." });
            }
        }
    }

    #endregion

    #region Delete

    public IActionResult Delete(int StaffId)
    {
        bool isDeleted = _staffBal.PR_Staff_Delete(StaffId);
        if (isDeleted)
        {
            return Ok();
        }
        else
        {
            return NotFound();
        }
    }

    #endregion

    #region Staff Profile

    [CustomAuthorize("Staff")]
    public IActionResult MyProfile()
    {
        var staffId = HttpContext.Session.GetInt32("UserID");
        if (staffId.HasValue)
        {
            var staffModel = _staffBal.PR_Staff_SelectById(staffId.Value);
            return View(staffModel);
        }
        
        return RedirectToAction("Index", "Dashboard", new { area = "" });
    }

    [HttpPost]
    [CustomAuthorize("Staff")]
    public IActionResult UpdateMyProfile(Models.Staff model)
    {
        if (ModelState.IsValid)
        {
            var staffId = HttpContext.Session.GetInt32("UserID");
            if (staffId.HasValue && model.StaffID == staffId.Value)
            {
                // Retrieve the existing staff record to preserve data that staff shouldn't modify
                var existingStaff = _staffBal.PR_Staff_SelectById(staffId.Value);
                
                // Update only the permitted fields
                existingStaff.StaffName = model.StaffName;
                existingStaff.ContectNo = model.ContectNo;
                existingStaff.Email = model.Email;
                existingStaff.Gender = model.Gender;
                
                // Only update password if provided
                if (!string.IsNullOrEmpty(model.Password))
                {
                    existingStaff.Password = model.Password;
                }
                
                if (_staffBal.PR_Staff_Update(existingStaff))
                {
                    return Json(new { success = true, message = "Profile updated successfully." });
                }
                else
                {
                    return Json(new { success = false, message = "An error occurred while updating your profile." });
                }
            }
            else
            {
                return Json(new { success = false, message = "You are not authorized to update this profile." });
            }
        }
        
        return View("MyProfile", model);
    }

    #endregion
}