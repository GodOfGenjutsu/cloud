﻿namespace Sanskar_Admin.Models;

public class DashboardViewModel
{
    public int NumberOfInquiries { get; set; }
    public int NumberOfStaff { get; set; }
    public int NumberOfStudents { get;set;}
    
    public List<Inquiry> Inquiries { get; set; }
}