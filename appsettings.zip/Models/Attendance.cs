﻿namespace Sanskar_Admin.Models;

public class Attendance
{
    public int AttendanceId { get; set; }
    public int StudentId { get; set; }
    public string StudentName { get; set; }
    public int StandardId { get; set; }
    public string StandardName { get; set; }
    public int DivisionId { get; set; }
    public string DivisionName { get; set; }
    public DateTime AttendanceDate { get; set; }
    public bool IsPresent { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? ModifiedAt { get; set; }
    public int StudentRollNumber { get; set; }
}