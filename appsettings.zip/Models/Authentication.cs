﻿namespace Sanskar_Admin.Models;

public class Authentication
{
    public int SanskarId { get; set; }
    public int AdminId { get; set; }
    public int StudentId { get; set; }
    public string Email { get; set; }
    public string Password { get; set; }
    public string ConfirmPassword { get; set; }
    public DateTime? CreatedAt { get; set; }
    public DateTime? ModifiedAt { get; set; }
}