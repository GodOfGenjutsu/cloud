﻿using System.ComponentModel.DataAnnotations;

namespace Sanskar_Admin.Models;

public class Staff
{
    [Required(ErrorMessage = "StaffId is required")]
    [Range(1, int.MaxValue, ErrorMessage = "StaffId must be a positive number")]
    public int StaffID { get; set; }

    [Required(ErrorMessage = "ClassesId is required")]
    [Range(1, int.MaxValue, ErrorMessage = "ClassesId must be a positive number")]
    public int SanskarId { get; set; }

    [Required(ErrorMessage = "Staff name is required.")]
    public string StaffName { get; set; }

    [Required(ErrorMessage = "Staff code is required.")]
    public string StaffCode { get; set; }

    public DateTime Birthdate { get; set; }

    [Required(ErrorMessage = "Staff contact is required")]
    [StringLength(10, MinimumLength = 10, ErrorMessage = "Contact must be 10 digits")]
    [RegularExpression(@"^\d{10}$", ErrorMessage = "Contact must be numeric and 10 digits")]
    public string ContectNo { get; set; }

    [EmailAddress(ErrorMessage = "Invalid email address.")]
    public string Email { get; set; }

    //staff password filed here
    [Required(ErrorMessage = "Password is required")]
    [StringLength(100, MinimumLength = 6, ErrorMessage = "Password must be at least 6 characters long.")]
    public string Password { get; set; }

    [Required] public DateTime JoiningDate { get; set; }

    [Required(ErrorMessage = "Salary is required")]
    [Range(0, 999999, ErrorMessage = "Salary must be a non-negative number And maximum 6 digits")]
    public int Salary { get; set; }
    [Required(ErrorMessage = "Gender is required")]
    [RegularExpression(@"^(?:m|M|male|Male|f|F|female|Female)$", ErrorMessage = "Invalid gender value")]
    public string Gender { get; set; }

    [Required] public string Remark { get; set; }

    public string FormattedBirthdate => Birthdate.ToString("dd/MM/yyyy");
    public string FormattedJoiningDate => JoiningDate.ToString("dd/MM/yyyy");
    public string? Role { get; set; }
}