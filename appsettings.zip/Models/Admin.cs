﻿/* namespace Sanskar_Admin.Models;

public class Admin
{
    public int AdminId { get; set; }
    public int ClassesId { get; set; }
    public string AdminName { get; set; }
    public string Email { get; set; }
    public string Password { get; set; }
    public DateTime? CreatedAt { get; set; }
    public DateTime? ModifiedAt { get; set; }
} */


using System.ComponentModel.DataAnnotations;

namespace Sanskar_Admin.Models;

public class Admin
{
    public int AdminId { get; set; }

    [Required(ErrorMessage = "Classes ID is required")]
    public int ClassesId { get; set; } // Renamed from ClassesId to SanskarId for consistency

    [Required(ErrorMessage = "Admin Name is required")]
    public string AdminName { get; set; }

    [Required(ErrorMessage = "Email is required")]
    [EmailAddress(ErrorMessage = "Invalid Email Address")]
    public string Email { get; set; }

    [Required(ErrorMessage = "Password is required")]
    public string Password { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? ModifiedAt { get; set; }
    
    public String? Role { get; set; }

    public string? ProfileImage { get; set; } // To store the image path/URL
}