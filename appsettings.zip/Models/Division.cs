﻿using System.ComponentModel.DataAnnotations;

namespace Sanskar_Admin.Models;

public class Division
{
    public int DivisionId { get; set; }

    [Required(ErrorMessage = "Division Name is required.")]
    [StringLength(50, ErrorMessage = "Division Name must be between {2} and {1} characters long.", MinimumLength = 2)]
    public string DivisionName { get; set; }

    [Required(ErrorMessage = "Standard is required.")]
    public int StandardId { get; set; }
    public string StandardName { get; set; }

    [Display(Name = "Start Date")]
    [Required(ErrorMessage = "Start Date is required.")]
    [DataType(DataType.Date)]
    public DateTime? StartDate { get; set; }

    [Display(Name = "End Date")]
    [Required(ErrorMessage = "End Date is required.")]
    [DataType(DataType.Date)]
    public DateTime? EndDate { get; set; }

    public DateTime? CreatedAt { get; set; }
    public DateTime? ModifiedAt { get; set; }
}