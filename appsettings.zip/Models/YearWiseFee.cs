﻿using System.ComponentModel.DataAnnotations;

namespace Sanskar_Admin.Models;

public class YearWiseFee
{
    public int YearWiseFeeId { get; set; }

    [Required(ErrorMessage = "BoardId is required")]
    public int BoardId { get; set; }

    public string BoardName { get; set; }

    [Required(ErrorMessage = "StandardId is required")]
    public int StandardId { get; set; }

    public string StandardName { get; set; }

    [Required(ErrorMessage = "MediumId is required")]
    public int MediumId { get; set; }

    public string MediumName { get; set; }

    [Required(ErrorMessage = "AcademicYearId is required")]
    public int AcademicYearId { get; set; }

    public string AcademicYear { get; set; }

    [Required(ErrorMessage = "TotalFees is required")]
    [Range(0,99999999,ErrorMessage = "Fee Must Be Greater Than 0 And Less Than 8 digits")]
    public decimal TotalFees { get; set; }

    [Required(ErrorMessage = "CreatedAt is required")]
    public DateTime CreatedAt { get; set; }

    public DateTime? ModifiedAt { get; set; }

    // Add StartingYear and EndingYear properties
    public int StartingYear { get; set; }

    public int EndingYear { get; set; }

    // Additional properties for names from AcademicYear
    public DateTime StartingMonth { get; set; }

    public DateTime EndingMonth { get; set; }
}