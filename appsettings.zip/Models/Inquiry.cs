﻿using System.ComponentModel.DataAnnotations;
using System.Security.Permissions;

namespace Sanskar_Admin.Models
{
    public class Inquiry
    {
        [Required(ErrorMessage = "Inquiry is required")]
        [Range(1, int.MaxValue, ErrorMessage = "InquiryId must be a positive number")]
        public int InquiryId { get; set; }

        [Required(ErrorMessage = "Sanskar is required")]
        [Range(1, int.MaxValue, ErrorMessage = "ClassesId must be a positive number")]
        public int SanskarId { get; set; }

        [Required(ErrorMessage = "Board is required")]
        [Range(1, int.MaxValue, ErrorMessage = "BoardId must be a positive number")]
        public int BoardId { get; set; }

        [Required(ErrorMessage = "Medium is required")]
        [Range(1, int.MaxValue, ErrorMessage = "MediumId must be a positive number")]
        public int MediumId { get; set; }

        [Required(ErrorMessage = "Standard is required")]
        [Range(1, int.MaxValue, ErrorMessage = "Standard must be a positive number")]
        public int StandardId { get; set; }

        [Required(ErrorMessage = "Student first name is required")]
        [StringLength(50, ErrorMessage = "Student first name must be between {2} and {1} characters",
            MinimumLength = 2)]
        public string StudentFirstName { get; set; }

        [StringLength(50, ErrorMessage = "Student middle name must be maximum {1} characters")]
        public string StudentMiddleName { get; set; }

        [Required(ErrorMessage = "Student last name is required")]
        [StringLength(50, ErrorMessage = "Student last name must be between {2} and {1} characters", MinimumLength = 2)]
        public string StudentLastName { get; set; }

        [Required(ErrorMessage = "Father Name is required")]
        [StringLength(50, ErrorMessage = "FatherName must be between {2} and {1} characters", MinimumLength = 2)]
        public string FatherName { get; set; }

        [Required(ErrorMessage = "Mother Name is required")]
        [StringLength(50, ErrorMessage = "MotherName must be between {2} and {1} characters", MinimumLength = 2)]
        public string MotherName { get; set; }

        [Required(ErrorMessage = "Parent Contact is required")]
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Parent Contact must be 10 digits")]
        [RegularExpression(@"^\d{10}$", ErrorMessage = "Parent Contact must be numeric and 10 digits")]
        public string ParentContact { get; set; }

        [StringLength(10, MinimumLength = 10, ErrorMessage = "Student Contact must be 10 digits")]
        [RegularExpression(@"^\d{10}$", ErrorMessage = "Student Contact must be numeric and 10 digits")]
        public string StudentContact { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email address")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Address is required")]
        [StringLength(100, ErrorMessage = "Address must be between {2} and {1} characters", MinimumLength = 5)]
        public string Address { get; set; }

        [Required(ErrorMessage = "Inquiry description is required")]
        [StringLength(500, ErrorMessage = "Inquiry description must be maximum {1} characters")]
        public string InquiryDescription { get; set; }

        [Required(ErrorMessage = "Gender is required")]
        [RegularExpression(@"^(?:m|M|male|Male|f|F|female|Female)$", ErrorMessage = "Invalid gender value")]
        public string Gender { get; set; }

        public string Medium { get; set; }
        public string BoardName { get; set; }
        public string MediumName { get; set; }
        public string StandardName { get; set; }
        public string ClassName { get; set; }
        public string Status { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}