﻿namespace Sanskar_Admin.Models;

public class StandardDropDownModel
{
    public int StandardId { get; set; }
    public string? StandardName { get; set; }
}