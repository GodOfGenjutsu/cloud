﻿using System.ComponentModel.DataAnnotations;
namespace Sanskar_Admin.Models;

public class Board
{
    public int BoardId { get; set; }
    public int SanskarId { get; set; }

    // [Microsoft.Build.Framework.Required(ErrorMessage = "BoardName is required")]
    [StringLength(100, ErrorMessage = "BoardName must be at most 100 characters long")]
    public string BoardName { get; set; }

    [Display(Name = "Created At")]
    [DataType(DataType.DateTime)]
    public DateTime? CreatedAt { get; set; }

    [Display(Name = "Modified At")]
    [DataType(DataType.DateTime)]
    public DateTime? ModifiedAt { get; set; }
}