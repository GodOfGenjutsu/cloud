﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Sanskar_Admin.Models
{
    public class Standard
    {
        public int StandardId { get; set; }
        public int SanskarID { get; set; }

        [Required(ErrorMessage = "Division Id is required")]
        public int DivisionId { get; set; }

        [Required(ErrorMessage = "Standard Name is required")]
        [StringLength(50, ErrorMessage = "Standard Name must be at most 50 characters long")]
        public string StandardName { get; set; }

        [Required(ErrorMessage = "Created At is required")]
        public DateTime? CreatedAt { get; set; }

        [Required(ErrorMessage = "Modified At is required")]
        public DateTime? ModifiedAt { get; set; }
    }
}