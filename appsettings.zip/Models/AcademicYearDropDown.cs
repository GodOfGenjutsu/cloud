﻿namespace Sanskar_Admin.Models;

public class AcademicYearDropDown
{
    public int AcademicYearId { get; set; }
    public string? AcademicYear { get; set; }
}