﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http; // Add this

namespace Sanskar_Admin.Models;

public class AdminProfileViewModel
{
    public int AdminId { get; set; }

    [Required(ErrorMessage = "Name is required")]
    [Display(Name = "Admin Name")]
    public string AdminName { get; set; }

    [Required(ErrorMessage = "Email is required")]
    [EmailAddress(ErrorMessage = "Invalid email address")]
    public string Email { get; set; }
    

    [Display(Name = "New Password")]
    [MinLength(6, ErrorMessage = "Password must be at least 6 characters")]
    public string NewPassword { get; set; }

    [Display(Name = "Confirm Password")]
    [Compare("NewPassword", ErrorMessage = "Passwords do not match")]
    public string ConfirmPassword { get; set; }

    [Display(Name = "Profile Image")]
    [DataType(DataType.Upload)]
    [MaxFileSize(2 * 1024 * 1024, ErrorMessage = "Maximum allowed file size is {1} bytes.")] // 2MB
    [AllowedExtensions(new string[] { ".jpg", ".jpeg", ".png" }, ErrorMessage = "Allowed extensions are jpg, jpeg, and png.")]
    public IFormFile? ProfileImage { get; set; }

    public string? ExistingProfileImage { get; set; }
}

// Custom validation attributes
public class MaxFileSizeAttribute : ValidationAttribute
{
    private readonly int _maxFileSize;

    public MaxFileSizeAttribute(int maxFileSize)
    {
        _maxFileSize = maxFileSize;
    }

    public override bool IsValid(object value)
    {
        var file = value as IFormFile;
        if (file != null)
        {
            return file.Length <= _maxFileSize;
        }

        return true; // If no file is uploaded, consider it valid
    }

    public override string FormatErrorMessage(string name)
    {
        return $"The {name} field exceeds the maximum file size of {_maxFileSize / (1024 * 1024)} MB.";
    }
}

public class AllowedExtensionsAttribute : ValidationAttribute
{
    private readonly string[] _extensions;

    public AllowedExtensionsAttribute(string[] extensions)
    {
        _extensions = extensions;
    }

    public override bool IsValid(object value)
    {
        var file = value as IFormFile;
        if (file != null)
        {
            var extension = Path.GetExtension(file.FileName).ToLowerInvariant();
            return _extensions.Contains(extension);
        }

        return true; // If no file is uploaded, consider it valid
    }

    public override string FormatErrorMessage(string name)
    {
        return $"The {name} field only allows the following extensions: {string.Join(", ", _extensions)}";
    }
}