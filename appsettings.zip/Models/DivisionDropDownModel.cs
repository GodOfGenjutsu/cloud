﻿namespace Sanskar_Admin.Models;

public class DivisionDropDownModel
{
    public int DivisionId { get; set; }
    public string? DivisionName { get; set; }
}