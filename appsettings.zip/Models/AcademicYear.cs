﻿using System.ComponentModel.DataAnnotations;

namespace Sanskar_Admin.Models;

public class AcademicYear
{
    public int AcademicYearId { get; set; }

    [Required(ErrorMessage = "StartingMonth is required")]
    public DateTime StartingMonth { get; set; }

    [Required(ErrorMessage = "EndingMonth is required")]
    public DateTime EndingMonth { get; set; }

    [Required(ErrorMessage = "StartingYear is required")]
    public int StartingYear 
    { 
        get => StartingMonth.Year; 
        set => StartingMonth = new DateTime(value, StartingMonth.Month, StartingMonth.Day); 
    }

    [Required(ErrorMessage = "EndingYear is required")]
    public int EndingYear 
    { 
        get => EndingMonth.Year; 
        set => EndingMonth = new DateTime(value, EndingMonth.Month, EndingMonth.Day); 
    }

    public DateTime? CreatedAt { get; set; }

    public DateTime? ModifiedAt { get; set; }
}