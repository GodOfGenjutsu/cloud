﻿namespace Sanskar_Admin.Models;

public class MediumDropDownModel
{
    public int MediumId { get; set; }
    public string? MediumName { get; set; }
}