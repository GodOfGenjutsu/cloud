﻿using System.ComponentModel.DataAnnotations;

namespace Sanskar_Admin.Models;

public class BoardDropDownModel
{
    [Required(ErrorMessage = "Please Select Board")]
    public int BoardId { get; set; }

    [Required(ErrorMessage = "Please Select Board")]
    public string? BoardName { get; set; }
}