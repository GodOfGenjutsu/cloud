﻿using System.ComponentModel.DataAnnotations;

namespace Sanskar_Admin.Models;

public class Subject
{
    public int SubjectId { get; set; }

    [Required(ErrorMessage = "Board is required")]
    public int BoardId { get; set; }

    [Required(ErrorMessage = "BoardName is required")]
    public string BoardName { get; set; }

    [Required(ErrorMessage = "Standard is required")]
    public int StandardId { get; set; }

    [Required(ErrorMessage = "StandardName is required")]
    public string StandardName { get; set; }

    [Required(ErrorMessage = "Medium is required")]
    public int MediumId { get; set; }

    [Required(ErrorMessage = "MediumName is required")]
    public string MediumName { get; set; }

    [Required(ErrorMessage = "SubjectCode is required")]
    public string SubjectCode { get; set; }

    [Required(ErrorMessage = "SubjectName is required")]
    public string SubjectName { get; set; }


    [Required(ErrorMessage = "IsActive Or Not is required")]
    public bool IsActive { get; set; }

    [Required(ErrorMessage = "CreatedAt is required")]
    public DateTime CreatedAt { get; set; }

    public DateTime? ModifiedAt { get; set; }
}