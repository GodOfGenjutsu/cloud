﻿using System.ComponentModel.DataAnnotations;

namespace Sanskar_Admin.Models;

public class Student
{
    public int StudentId { get; set; }

    [Required(ErrorMessage = "Please Select Standard")]
    public int StandardId { get; set; }

    public string StandardName { get; set; }

    [Required(ErrorMessage = "Please Select Division")]
    public int DivisionId { get; set; }

    public string DivisionName { get; set; }

    [Required(ErrorMessage = "Class  is required")]
    public int SanskarId { get; set; }

    public string SanskarName { get; set; }
    

    [Required(ErrorMessage = "Please select Board")]
    public int BoardId { get; set; }

    public string BoardName { get; set; }

    [Required(ErrorMessage = "Please Select Medium")]
    public int MediumId { get; set; }

    public string MediumName { get; set; }

    [Required(ErrorMessage = "First Name is required")]
    [StringLength(50, ErrorMessage = "First Name cannot be longer than 50 characters")]
    public string StudentFirstName { get; set; }

    [Required(ErrorMessage = "Middle Name is required")]
    [StringLength(50, ErrorMessage = "Middle Name cannot be longer than 50 characters")]
    public string StudentMiddleName { get; set; }

    [Required(ErrorMessage = "Last Name is required")]
    [StringLength(50, ErrorMessage = "Last Name cannot be longer than 50 characters")]
    public string StudentLastName { get; set; }

    [Required(ErrorMessage = "Father's Name is required")]
    [StringLength(50, ErrorMessage = "Father's Name cannot be longer than 50 characters")]
    public string FatherName { get; set; }

    [StringLength(50, ErrorMessage = "Mother's Name cannot be longer than 50 characters")]
    public string MotherName { get; set; }

    [Required(ErrorMessage = "Parent Contact is required")]
    [StringLength(10, MinimumLength = 10, ErrorMessage = "Parent Contact must be 10 digits")]
    [RegularExpression(@"^\d{10}$", ErrorMessage = "Parent Contact must be numeric and 10 digits")]
    public string ParentContact { get; set; }

    [StringLength(10, MinimumLength = 10, ErrorMessage = "Student Contact must be 10 digits")]
    [RegularExpression(@"^\d{10}$", ErrorMessage = "Student Contact must be numeric and 10 digits")]
    public string StudentContact { get; set; }

    [Required(ErrorMessage = "Email is required")]
    [EmailAddress(ErrorMessage = "Invalid email address")]
    public string? Email { get; set; }

    [StringLength(255, ErrorMessage = "Address cannot be longer than 255 characters")]
    public string? Address { get; set; }

    [Required(ErrorMessage = "Password is required")]
    public string? Password { get; set; }

    [RegularExpression("^(Male|Female)$", ErrorMessage = "Invalid Gender")]
    public string? Gender { get; set; }

    [Required(ErrorMessage = "Please Enter Student RollNumber")]
    public int? StudentRollNumber { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? ModifiedAt { get; set; }
    public string? Role { get; set; }


    public static Student ConvertToStudent(Inquiry inquiry)
    {
        if (inquiry == null)
        {
            throw new ArgumentNullException(nameof(inquiry));
        }

        return new Student
        {
            StandardId = inquiry.StandardId,
            DivisionId = 1, // Replace with the appropriate value for DivisionId
            SanskarId = inquiry.SanskarId,
            BoardId = inquiry.BoardId,
            MediumId = inquiry.MediumId,
            StudentFirstName = inquiry.StudentFirstName,
            StudentMiddleName = inquiry.StudentMiddleName,
            StudentLastName = inquiry.StudentLastName,
            FatherName = inquiry.FatherName,
            MotherName = inquiry.MotherName,
            ParentContact = inquiry.ParentContact,
            StudentContact = inquiry.StudentContact,
            Email = inquiry.Email,
            Address = inquiry.Address,
            Gender = inquiry.Gender,
            Password = null, // Set the appropriate value for Password
            StudentRollNumber = 1, // Replace with the appropriate value for StudentRollNumber
            CreatedAt = DateTime.Now,
            ModifiedAt = null // You may set this to null or a default value
        };
    }
}