﻿using System.ComponentModel.DataAnnotations;

namespace Sanskar_Admin.Models;

public class Medium
{
    public int MediumId { get; set; }

    public int SanskarID { get; set; }

    [Required(ErrorMessage = "MediumName is required")]
    [StringLength(50, ErrorMessage = "MediumName must be no longer than 50 characters")]
    public string? MediumName { get; set; }

    [Display(Name = "Created At")] public DateTime? CreatedAt { get; set; }

    [Display(Name = "Modified At")] public DateTime? ModifiedAt { get; set; }
}