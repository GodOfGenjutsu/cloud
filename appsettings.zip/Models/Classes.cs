﻿namespace Sanskar_Admin.Models;

public class Sanskar
{
    public int SanskarId { get; set; }
    public string SanskarName { get; set; }
    public string SanskarDescription { get; set; }
    public string SanskarAddress { get; set; }
    public string SanskarContact { get; set; }
    public DateTime? CreatedAt { get; set; }
    public DateTime? ModifiedAt { get; set; }
}