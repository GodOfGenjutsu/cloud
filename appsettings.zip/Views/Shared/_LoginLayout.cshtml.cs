﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Sanskar_Admin.Views.Shared;

public class _LoginLayout : PageModel
{
    public void OnGet()
    {
        
    }
}